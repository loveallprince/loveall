import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  CreditCard, 
  Check, 
  Star, 
  Shield, 
  Users, 
  MapPin, 
  Calendar,
  Crown,
  Zap,
  Heart
} from 'lucide-react';

interface SubscriptionDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: (subscriptionData: any) => void;
  userEmail: string;
  userName: string;
}

export const SubscriptionDialog: React.FC<SubscriptionDialogProps> = ({ 
  isOpen, 
  onClose, 
  onSubscribe, 
  userEmail, 
  userName 
}) => {
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardHolder: userName
  });

  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayment = async () => {
    if (!paymentData.cardNumber || !paymentData.expiryDate || !paymentData.cvv) {
      alert('모든 결제 정보를 입력해주세요.');
      return;
    }

    setIsProcessing(true);
    
    // Mock payment processing
    setTimeout(() => {
      const subscriptionData = {
        plan: 'premium',
        status: 'active',
        nextPaymentDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        paymentMethod: `**** **** **** ${paymentData.cardNumber.slice(-4)}`,
        amount: 2000,
        startDate: new Date().toISOString().split('T')[0]
      };
      
      onSubscribe(subscriptionData);
      setIsProcessing(false);
      onClose();
    }, 2000);
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`;
    }
    return v;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            Love All 프리미엄 구독
          </DialogTitle>
          <DialogDescription>
            더 나은 테니스 경험을 위한 프리미엄 서비스를 시작하세요
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Subscription Plan */}
          <Card className="border-2 border-green-200 bg-green-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-green-600" />
                  Love All 프리미엄
                </CardTitle>
                <Badge className="bg-green-600 text-white">
                  추천
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">₩2,000</div>
                  <div className="text-gray-600">매월</div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">전국 모든 테니스장 예약</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">무제한 모임 참여</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">프로 코치 레슨 할인</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">프리미엄 테니스장 예약</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">우선 예약 시스템</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">개인별 맞춤 추천</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">24/7 고객지원</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                결제 정보
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="cardNumber">카드번호</Label>
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={paymentData.cardNumber}
                  onChange={(e) => setPaymentData({
                    ...paymentData, 
                    cardNumber: formatCardNumber(e.target.value)
                  })}
                  maxLength={19}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiryDate">유효기간</Label>
                  <Input
                    id="expiryDate"
                    placeholder="MM/YY"
                    value={paymentData.expiryDate}
                    onChange={(e) => setPaymentData({
                      ...paymentData, 
                      expiryDate: formatExpiryDate(e.target.value)
                    })}
                    maxLength={5}
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={paymentData.cvv}
                    onChange={(e) => setPaymentData({
                      ...paymentData, 
                      cvv: e.target.value.replace(/[^0-9]/g, '')
                    })}
                    maxLength={3}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="cardHolder">카드 소유자</Label>
                <Input
                  id="cardHolder"
                  value={paymentData.cardHolder}
                  onChange={(e) => setPaymentData({
                    ...paymentData, 
                    cardHolder: e.target.value
                  })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Billing Summary */}
          <Card className="bg-gray-50">
            <CardHeader>
              <CardTitle className="text-lg">결제 요약</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Love All 프리미엄 (월)</span>
                  <span>₩2,000</span>
                </div>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>VAT 포함</span>
                  <span>₩200</span>
                </div>
                <Separator />
                <div className="flex justify-between font-semibold">
                  <span>총 결제 금액</span>
                  <span>₩2,000</span>
                </div>
                <div className="text-sm text-gray-600">
                  다음 결제일: {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Terms and Conditions */}
          <div className="text-sm text-gray-600 space-y-2">
            <p>
              결제 버튼을 클릭하면 <Button variant="link" className="p-0 h-auto text-sm">이용약관</Button> 및{' '}
              <Button variant="link" className="p-0 h-auto text-sm">개인정보처리방침</Button>에 동의하는 것으로 간주됩니다.
            </p>
            <p>
              구독은 언제든지 취소할 수 있으며, 취소 시 다음 결제일까지 서비스를 이용할 수 있습니다.
            </p>
          </div>

          {/* Payment Button */}
          <div className="space-y-4">
            <Button 
              onClick={handlePayment}
              disabled={isProcessing}
              className="w-full h-12 bg-green-600 hover:bg-green-700"
              size="lg"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  결제 처리 중...
                </>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 mr-2" />
                  ₩2,000 결제하고 구독 시작
                </>
              )}
            </Button>
            
            <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
              <Shield className="w-4 h-4" />
              <span>안전한 결제 시스템으로 보호됩니다</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};