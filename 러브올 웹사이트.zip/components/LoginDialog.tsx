import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { SubscriptionDialog } from './SubscriptionDialog';
import { Eye, EyeOff, User, Mail, Phone, Crown, Star, Check } from 'lucide-react';

interface LoginDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (userData: any) => void;
}

export const LoginDialog: React.FC<LoginDialogProps> = ({ isOpen, onClose, onLogin }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false);
  const [pendingUserData, setPendingUserData] = useState<any>(null);
  
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });
  const [registerData, setRegisterData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: ''
  });

  const handleLogin = () => {
    if (!loginData.email || !loginData.password) {
      alert('이메일과 비밀번호를 입력해주세요.');
      return;
    }

    // Mock login - In real app, this would be an API call
    const userData = {
      name: '테니스러버',
      email: loginData.email,
      phone: '010-1234-5678',
      bio: '테니스를 사랑하는 사람입니다.',
      favoriteLevel: '중급',
      joinDate: '2025-01-15',
      subscription: {
        plan: 'premium',
        status: 'active',
        nextPaymentDate: '2025-08-17',
        paymentMethod: '**** **** **** 1234',
        amount: 2000,
        startDate: '2025-07-17'
      }
    };

    onLogin(userData);
    onClose();
    setLoginData({ email: '', password: '' });
  };

  const handleRegister = () => {
    if (!registerData.name || !registerData.email || !registerData.password) {
      alert('필수 정보를 모두 입력해주세요.');
      return;
    }

    if (registerData.password !== registerData.confirmPassword) {
      alert('비밀번호가 일치하지 않습니다.');
      return;
    }

    // Store user data and show subscription dialog
    const userData = {
      name: registerData.name,
      email: registerData.email,
      phone: registerData.phone,
      bio: '',
      favoriteLevel: '초급',
      joinDate: new Date().toISOString().split('T')[0]
    };

    setPendingUserData(userData);
    setShowSubscriptionDialog(true);
  };

  const handleSubscription = (subscriptionData: any) => {
    const completeUserData = {
      ...pendingUserData,
      subscription: subscriptionData
    };

    onLogin(completeUserData);
    setShowSubscriptionDialog(false);
    onClose();
    
    // Reset form data
    setRegisterData({
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      phone: ''
    });
    setPendingUserData(null);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[450px]" aria-describedby="login-dialog-description">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">🎾</span>
                </div>
                <span className="text-xl font-bold">Love All</span>
              </div>
            </DialogTitle>
            <DialogDescription id="login-dialog-description">
              Love All 서비스를 이용하기 위해 로그인하거나 새 계정을 만드세요.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">로그인</TabsTrigger>
              <TabsTrigger value="register">회원가입</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">로그인</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="email">이메일</Label>
                    <div className="relative">
                      <Input
                        id="email"
                        type="email"
                        placeholder="example@email.com"
                        value={loginData.email}
                        onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                        className="pl-10"
                        autoComplete="email"
                      />
                      <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="password">비밀번호</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="비밀번호를 입력하세요"
                        value={loginData.password}
                        onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                        className="pr-10"
                        autoComplete="current-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        aria-label={showPassword ? "비밀번호 숨기기" : "비밀번호 보기"}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <Button 
                    onClick={handleLogin}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    로그인
                  </Button>

                  <div className="text-center">
                    <Button variant="link" className="text-sm text-gray-600">
                      비밀번호를 잊으셨나요?
                    </Button>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">
                        또는
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="outline" className="w-full">
                      <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                      구글
                    </Button>
                    <Button variant="outline" className="w-full">
                      <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16c-.169 1.858-.896 3.587-2.043 4.568-.444.379-.978.688-1.597.919-.619.23-1.297.35-2.029.35s-1.407-.12-2.029-.35c-.619-.231-1.153-.54-1.597-.919-1.147-.981-1.874-2.71-2.043-4.568-.014-.148-.019-.297-.019-.446 0-.148.005-.298.019-.446.169-1.858.896-3.587 2.043-4.568.444-.379.978-.688 1.597-.919.622-.23 1.297-.35 2.029-.35s1.407.12 2.029.35c.619.231 1.153.54 1.597.919 1.147.981 1.874 2.71 2.043 4.568.014.148.019.298.019.446 0 .149-.005.298-.019.446z"/>
                      </svg>
                      카카오
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="register" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">회원가입</CardTitle>
                  <div className="text-center">
                    <Badge className="bg-green-600 text-white">
                      <Crown className="w-3 h-3 mr-1" />
                      프리미엄 구독 포함
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Premium Benefits Preview */}
                  <div className="bg-green-50 rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2 text-green-700">
                      <Star className="w-4 h-4" />
                      <span className="font-medium">프리미엄 혜택 (월 ₩2,000)</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-sm text-green-600">
                      <div className="flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>무제한 예약</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>우선 예약권</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>프로 레슨 할인</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>24/7 지원</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="register-name">이름</Label>
                    <div className="relative">
                      <Input
                        id="register-name"
                        placeholder="이름을 입력하세요"
                        value={registerData.name}
                        onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
                        className="pl-10"
                        autoComplete="name"
                      />
                      <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="register-email">이메일</Label>
                    <div className="relative">
                      <Input
                        id="register-email"
                        type="email"
                        placeholder="example@email.com"
                        value={registerData.email}
                        onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                        className="pl-10"
                        autoComplete="email"
                      />
                      <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="register-password">비밀번호</Label>
                    <div className="relative">
                      <Input
                        id="register-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="비밀번호를 입력하세요"
                        value={registerData.password}
                        onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                        className="pr-10"
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                        aria-label={showPassword ? "비밀번호 숨기기" : "비밀번호 보기"}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="confirm-password">비밀번호 확인</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="비밀번호를 다시 입력하세요"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                      autoComplete="new-password"
                    />
                  </div>

                  <div>
                    <Label htmlFor="register-phone">전화번호 (선택)</Label>
                    <div className="relative">
                      <Input
                        id="register-phone"
                        placeholder="010-1234-5678"
                        value={registerData.phone}
                        onChange={(e) => setRegisterData({...registerData, phone: e.target.value})}
                        className="pl-10"
                        autoComplete="tel"
                      />
                      <Phone className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    </div>
                  </div>

                  <Button 
                    onClick={handleRegister}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Crown className="w-4 h-4 mr-2" />
                    프리미엄 구독하고 회원가입
                  </Button>

                  <div className="text-center">
                    <p className="text-sm text-gray-600">
                      회원가입 시 <Button variant="link" className="p-0 h-auto text-sm">이용약관</Button> 및{' '}
                      <Button variant="link" className="p-0 h-auto text-sm">개인정보처리방침</Button>에 동의합니다.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Subscription Dialog */}
      {showSubscriptionDialog && pendingUserData && (
        <SubscriptionDialog
          isOpen={showSubscriptionDialog}
          onClose={() => setShowSubscriptionDialog(false)}
          onSubscribe={handleSubscription}
          userEmail={pendingUserData.email}
          userName={pendingUserData.name}
        />
      )}
    </>
  );
};