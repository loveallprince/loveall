import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { User, Calendar, MapPin, Users, Star, Edit, Trash2, Settings } from 'lucide-react';

interface MyPageProps {
  user: {
    name: string;
    email: string;
    phone?: string;
    bio?: string;
    favoriteLevel?: string;
    joinDate?: string;
  };
  onUpdateProfile: (userData: any) => void;
}

export const MyPage: React.FC<MyPageProps> = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState(user);

  // Mock data for user's meetings and reviews
  const myMeetings = [
    {
      id: '1',
      title: '주말 테니스 모임',
      date: '2025-07-12',
      time: '09:00',
      location: '올림픽공원 테니스장',
      status: 'upcoming',
      participants: 5,
      maxParticipants: 8
    },
    {
      id: '2',
      title: '평일 저녁 복식 게임',
      date: '2025-07-05',
      time: '19:00',
      location: '한강시민공원 테니스장',
      status: 'completed',
      participants: 4,
      maxParticipants: 4
    }
  ];

  const myParticipations = [
    {
      id: '3',
      title: '테니스 레슨 그룹',
      date: '2025-07-15',
      time: '14:00',
      location: '부산 해운대 테니스장',
      status: 'upcoming',
      organizer: '프로코치김'
    },
    {
      id: '4',
      title: '주말 테니스 모임',
      date: '2025-06-28',
      time: '10:00',
      location: '올림픽공원 테니스장',
      status: 'completed',
      organizer: '테니스맨'
    }
  ];

  const myReviews = [
    {
      id: '1',
      type: 'court',
      targetName: '올림픽공원 테니스장',
      rating: 5,
      title: '시설이 정말 좋아요!',
      date: '2025-07-05',
      helpful: 12
    },
    {
      id: '2',
      type: 'meeting',
      targetName: '주말 테니스 모임',
      rating: 4,
      title: '즐거운 모임이었어요',
      date: '2025-07-03',
      helpful: 8
    }
  ];

  const handleSaveProfile = () => {
    onUpdateProfile(editData);
    setIsEditing(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'upcoming':
        return <Badge variant="default">예정</Badge>;
      case 'completed':
        return <Badge variant="secondary">완료</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">취소</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">마이페이지</h1>
        <p className="text-gray-600 mt-2">내 정보와 활동을 관리해보세요</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Section */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  프로필
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <Avatar className="w-24 h-24 mx-auto mb-4">
                  <AvatarImage src="/avatars/01.png" alt={user.name} />
                  <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
              </div>

              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">이름</Label>
                    <Input
                      id="name"
                      value={editData.name}
                      onChange={(e) => setEditData({...editData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">이메일</Label>
                    <Input
                      id="email"
                      value={editData.email}
                      onChange={(e) => setEditData({...editData, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">전화번호</Label>
                    <Input
                      id="phone"
                      value={editData.phone || ''}
                      onChange={(e) => setEditData({...editData, phone: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="bio">자기소개</Label>
                    <Textarea
                      id="bio"
                      value={editData.bio || ''}
                      onChange={(e) => setEditData({...editData, bio: e.target.value})}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="favoriteLevel">선호 레벨</Label>
                    <Input
                      id="favoriteLevel"
                      value={editData.favoriteLevel || ''}
                      onChange={(e) => setEditData({...editData, favoriteLevel: e.target.value})}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleSaveProfile}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                    >
                      저장
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setIsEditing(false)}
                      className="flex-1"
                    >
                      취소
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">{user.name}</h3>
                    <p className="text-gray-600">{user.email}</p>
                  </div>
                  
                  {user.phone && (
                    <div>
                      <Label className="text-sm font-medium">전화번호</Label>
                      <p className="text-gray-600">{user.phone}</p>
                    </div>
                  )}
                  
                  {user.bio && (
                    <div>
                      <Label className="text-sm font-medium">자기소개</Label>
                      <p className="text-gray-600">{user.bio}</p>
                    </div>
                  )}
                  
                  {user.favoriteLevel && (
                    <div>
                      <Label className="text-sm font-medium">선호 레벨</Label>
                      <Badge variant="outline">{user.favoriteLevel}</Badge>
                    </div>
                  )}
                  
                  <div>
                    <Label className="text-sm font-medium">가입일</Label>
                    <p className="text-gray-600">{user.joinDate || '2025-01-01'}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Activity Section */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="my-meetings" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="my-meetings">내 모임</TabsTrigger>
              <TabsTrigger value="participations">참여 모임</TabsTrigger>
              <TabsTrigger value="reviews">내 리뷰</TabsTrigger>
            </TabsList>
            
            <TabsContent value="my-meetings" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>내가 개설한 모임</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myMeetings.map((meeting) => (
                      <div key={meeting.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold">{meeting.title}</h3>
                          <div className="flex gap-2">
                            {getStatusBadge(meeting.status)}
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {meeting.date} {meeting.time}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {meeting.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {meeting.participants}/{meeting.maxParticipants}명
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="participations" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>참여 신청한 모임</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myParticipations.map((participation) => (
                      <div key={participation.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold">{participation.title}</h3>
                          {getStatusBadge(participation.status)}
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {participation.date} {participation.time}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {participation.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            주최자: {participation.organizer}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>내가 작성한 리뷰</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {myReviews.map((review) => (
                      <div key={review.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-semibold">{review.title}</h3>
                            <p className="text-sm text-gray-600">
                              {review.targetName} • {review.date}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex items-center gap-1">
                              {renderStars(review.rating)}
                            </div>
                            <Badge variant={review.type === 'court' ? 'default' : 'secondary'}>
                              {review.type === 'court' ? '테니스장' : '모임'}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">
                            👍 도움돼요 ({review.helpful})
                          </span>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};