import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Star, 
  Clock, 
  TrendingUp,
  Award,
  Bell,
  Plus,
  ChevronRight,
  Activity,
  Target,
  Heart,
  Zap
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface User {
  name: string;
  email: string;
  phone?: string;
  bio?: string;
  favoriteLevel?: string;
  joinDate?: string;
}

interface UserDashboardProps {
  user: User;
  onPageChange: (page: string) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ user, onPageChange }) => {
  // Mock data for user's activities
  const recentBookings = [
    {
      id: 1,
      courtName: '올림픽공원 테니스장',
      date: '2025-07-20',
      time: '14:00-16:00',
      status: '예약완료',
      type: '하드코트'
    },
    {
      id: 2,
      courtName: '한강시민공원 테니스장',
      date: '2025-07-25',
      time: '09:00-11:00',
      status: '예약완료',
      type: '클레이코트'
    }
  ];

  const joinedMeetings = [
    {
      id: 1,
      title: '주말 테니스 모임',
      date: '2025-07-22',
      time: '10:00',
      location: '올림픽공원 테니스장',
      organizer: '테니스마스터',
      participants: 6
    },
    {
      id: 2,
      title: '평일 저녁 복식',
      date: '2025-07-24',
      time: '19:00',
      location: '한강시민공원 테니스장',
      organizer: '라켓매니아',
      participants: 4
    }
  ];

  const achievements = [
    { title: '첫 예약 완료', icon: '🎾', date: '2025-07-15' },
    { title: '첫 모임 참여', icon: '👥', date: '2025-07-16' },
    { title: '리뷰 작성자', icon: '⭐', date: '2025-07-17' }
  ];

  const notifications = [
    { type: 'booking', message: '올림픽공원 테니스장 예약이 확정되었습니다', time: '2시간 전' },
    { type: 'meeting', message: '주말 테니스 모임에 새로운 참가자가 있습니다', time: '4시간 전' },
    { type: 'system', message: '새로운 테니스장이 추가되었습니다', time: '1일 전' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-6">
          <Avatar className="w-16 h-16">
            <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} />
            <AvatarFallback>{user.name[0]}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              안녕하세요, {user.name}님! 🎾
            </h1>
            <p className="text-gray-600 mt-1">
              오늘도 즐거운 테니스 한 게임 어떠세요?
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button 
            variant="outline" 
            className="h-20 flex-col gap-2"
            onClick={() => onPageChange('courts')}
          >
            <MapPin className="w-6 h-6 text-green-600" />
            <span>테니스장 예약</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-20 flex-col gap-2"
            onClick={() => onPageChange('meetings')}
          >
            <Users className="w-6 h-6 text-blue-600" />
            <span>모임 찾기</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-20 flex-col gap-2"
            onClick={() => onPageChange('pro-services')}
          >
            <Award className="w-6 h-6 text-purple-600" />
            <span>프로 레슨</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-20 flex-col gap-2"
            onClick={() => onPageChange('mypage')}
          >
            <Activity className="w-6 h-6 text-orange-600" />
            <span>내 활동</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Activity Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                이번 달 활동 통계
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">3</div>
                  <div className="text-sm text-gray-600">예약한 코트</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">5</div>
                  <div className="text-sm text-gray-600">참여한 모임</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">2</div>
                  <div className="text-sm text-gray-600">작성한 리뷰</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">8</div>
                  <div className="text-sm text-gray-600">플레이 시간</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Bookings */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                최근 예약
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => onPageChange('mypage')}>
                전체보기 <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentBookings.map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <MapPin className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{booking.courtName}</h4>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>{booking.date}</span>
                          <span>{booking.time}</span>
                          <Badge variant="outline">{booking.type}</Badge>
                        </div>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      {booking.status}
                    </Badge>
                  </div>
                ))}
                {recentBookings.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>아직 예약한 테니스장이 없습니다</p>
                    <Button 
                      className="mt-4 bg-green-600 hover:bg-green-700"
                      onClick={() => onPageChange('courts')}
                    >
                      테니스장 예약하기
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Joined Meetings */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                참여 중인 모임
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => onPageChange('meetings')}>
                전체보기 <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {joinedMeetings.map((meeting) => (
                  <div key={meeting.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{meeting.title}</h4>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>{meeting.date} {meeting.time}</span>
                          <span>{meeting.location}</span>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          주최: {meeting.organizer} • 참여자 {meeting.participants}명
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      상세보기
                    </Button>
                  </div>
                ))}
                {joinedMeetings.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>참여 중인 모임이 없습니다</p>
                    <Button 
                      className="mt-4 bg-blue-600 hover:bg-blue-700"
                      onClick={() => onPageChange('meetings')}
                    >
                      모임 찾아보기
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Notifications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                알림
                <Badge variant="destructive" className="ml-auto">
                  {notifications.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {notifications.map((notification, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                  </div>
                ))}
                <Button variant="outline" className="w-full" size="sm">
                  모든 알림 보기
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                최근 달성
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                    <span className="text-2xl">{achievement.icon}</span>
                    <div>
                      <div className="font-medium text-sm">{achievement.title}</div>
                      <div className="text-xs text-gray-500">{achievement.date}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommended for You */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                맞춤 추천
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">강남 테니스장</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    당신의 위치와 선호도를 바탕으로 추천드려요
                  </p>
                  <Button size="sm" variant="outline" className="w-full">
                    자세히 보기
                  </Button>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">중급자 모임</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    당신의 실력 레벨에 맞는 모임을 찾았어요
                  </p>
                  <Button size="sm" variant="outline" className="w-full">
                    참여하기
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                레벨 정보
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">현재 레벨</span>
                  <Badge variant="secondary">{user.favoriteLevel || '초급'}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">가입일</span>
                  <span className="text-sm text-gray-600">{user.joinDate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">총 플레이 시간</span>
                  <span className="text-sm font-medium">24시간</span>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full" 
                  size="sm"
                  onClick={() => onPageChange('mypage')}
                >
                  프로필 수정하기
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};