import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar, MapPin, Users, Clock, Plus, Filter } from 'lucide-react';

interface Meeting {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  maxParticipants: number;
  currentParticipants: number;
  organizer: string;
  level: string;
  fee: string;
  status: 'open' | 'full' | 'closed';
  tags: string[];
}

interface MeetingListProps {
  isLoggedIn: boolean;
}

export const MeetingList: React.FC<MeetingListProps> = ({ isLoggedIn }) => {
  const [meetings, setMeetings] = useState<Meeting[]>([
    {
      id: '1',
      title: '주말 테니스 모임',
      description: '초보자부터 중급자까지 환영합니다. 재미있게 테니스를 즐겨요!',
      date: '2025-07-12',
      time: '09:00',
      location: '올림픽공원 테니스장',
      maxParticipants: 8,
      currentParticipants: 5,
      organizer: '테니스맨',
      level: '초중급',
      fee: '10,000원',
      status: 'open',
      tags: ['주말', '초보환영', '단식']
    },
    {
      id: '2',
      title: '평일 저녁 복식 게임',
      description: '퇴근 후 스트레스 해소를 위한 복식 게임입니다.',
      date: '2025-07-10',
      time: '19:00',
      location: '한강시민공원 테니스장',
      maxParticipants: 4,
      currentParticipants: 4,
      organizer: '라켓매니아',
      level: '중급',
      fee: '15,000원',
      status: 'full',
      tags: ['평일', '복식', '중급']
    },
    {
      id: '3',
      title: '테니스 레슨 그룹',
      description: '전문 코치와 함께하는 그룹 레슨입니다.',
      date: '2025-07-15',
      time: '14:00',
      location: '부산 해운대 테니스장',
      maxParticipants: 6,
      currentParticipants: 3,
      organizer: '프로코치김',
      level: '초급',
      fee: '30,000원',
      status: 'open',
      tags: ['레슨', '코치', '초급']
    }
  ]);

  const [filterLevel, setFilterLevel] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newMeeting, setNewMeeting] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    location: '',
    maxParticipants: 4,
    level: '',
    fee: ''
  });

  const filteredMeetings = meetings.filter(meeting => {
    const levelMatch = filterLevel === 'all' || meeting.level === filterLevel;
    const statusMatch = filterStatus === 'all' || meeting.status === filterStatus;
    return levelMatch && statusMatch;
  });

  const handleCreateMeeting = () => {
    if (!newMeeting.title || !newMeeting.date || !newMeeting.time || !newMeeting.location) {
      alert('필수 정보를 모두 입력해주세요.');
      return;
    }

    const meeting: Meeting = {
      id: Date.now().toString(),
      title: newMeeting.title,
      description: newMeeting.description,
      date: newMeeting.date,
      time: newMeeting.time,
      location: newMeeting.location,
      maxParticipants: newMeeting.maxParticipants,
      currentParticipants: 1,
      organizer: '현재 사용자',
      level: newMeeting.level,
      fee: newMeeting.fee,
      status: 'open',
      tags: []
    };

    setMeetings([meeting, ...meetings]);
    setShowCreateDialog(false);
    setNewMeeting({
      title: '',
      description: '',
      date: '',
      time: '',
      location: '',
      maxParticipants: 4,
      level: '',
      fee: ''
    });
  };

  const handleJoinMeeting = (meetingId: string) => {
    setMeetings(meetings.map(meeting => {
      if (meeting.id === meetingId && meeting.currentParticipants < meeting.maxParticipants) {
        const newParticipants = meeting.currentParticipants + 1;
        return {
          ...meeting,
          currentParticipants: newParticipants,
          status: newParticipants === meeting.maxParticipants ? 'full' : 'open'
        };
      }
      return meeting;
    }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">테니스 모임</h1>
          <p className="text-gray-600 mt-2">동호회 모임에 참여하거나 직접 모임을 만들어보세요</p>
        </div>
        
        <div className="flex gap-4">
          <Select value={filterLevel} onValueChange={setFilterLevel}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="레벨 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체 레벨</SelectItem>
              <SelectItem value="초급">초급</SelectItem>
              <SelectItem value="초중급">초중급</SelectItem>
              <SelectItem value="중급">중급</SelectItem>
              <SelectItem value="중상급">중상급</SelectItem>
              <SelectItem value="상급">상급</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="상태 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체 상태</SelectItem>
              <SelectItem value="open">모집중</SelectItem>
              <SelectItem value="full">모집완료</SelectItem>
              <SelectItem value="closed">모집종료</SelectItem>
            </SelectContent>
          </Select>
          
          {isLoggedIn && (
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  모임 만들기
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]" aria-describedby="create-meeting-description">
                <DialogHeader>
                  <DialogTitle>새 테니스 모임 만들기</DialogTitle>
                  <DialogDescription id="create-meeting-description">
                    새로운 테니스 모임을 만들어 다른 회원들과 함께 테니스를 즐겨보세요.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">모임 제목</Label>
                    <Input
                      id="title"
                      placeholder="모임 제목을 입력하세요"
                      value={newMeeting.title}
                      onChange={(e) => setNewMeeting({...newMeeting, title: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">모임 설명</Label>
                    <Textarea
                      id="description"
                      placeholder="모임에 대한 설명을 입력하세요"
                      value={newMeeting.description}
                      onChange={(e) => setNewMeeting({...newMeeting, description: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="date">날짜</Label>
                      <Input
                        id="date"
                        type="date"
                        value={newMeeting.date}
                        onChange={(e) => setNewMeeting({...newMeeting, date: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="time">시간</Label>
                      <Input
                        id="time"
                        type="time"
                        value={newMeeting.time}
                        onChange={(e) => setNewMeeting({...newMeeting, time: e.target.value})}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="location">장소</Label>
                    <Input
                      id="location"
                      placeholder="테니스장 이름을 입력하세요"
                      value={newMeeting.location}
                      onChange={(e) => setNewMeeting({...newMeeting, location: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="maxParticipants">최대 인원</Label>
                      <Input
                        id="maxParticipants"
                        type="number"
                        min="2"
                        max="20"
                        value={newMeeting.maxParticipants}
                        onChange={(e) => setNewMeeting({...newMeeting, maxParticipants: parseInt(e.target.value)})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="level">레벨</Label>
                      <Select 
                        value={newMeeting.level} 
                        onValueChange={(value) => setNewMeeting({...newMeeting, level: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="레벨 선택" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="초급">초급</SelectItem>
                          <SelectItem value="초중급">초중급</SelectItem>
                          <SelectItem value="중급">중급</SelectItem>
                          <SelectItem value="중상급">중상급</SelectItem>
                          <SelectItem value="상급">상급</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="fee">참가비</Label>
                    <Input
                      id="fee"
                      placeholder="예: 10,000원"
                      value={newMeeting.fee}
                      onChange={(e) => setNewMeeting({...newMeeting, fee: e.target.value})}
                    />
                  </div>
                  
                  <Button 
                    onClick={handleCreateMeeting}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    모임 만들기
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMeetings.map((meeting) => (
          <Card key={meeting.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{meeting.title}</CardTitle>
                <Badge 
                  variant={meeting.status === 'open' ? 'default' : meeting.status === 'full' ? 'secondary' : 'destructive'}
                >
                  {meeting.status === 'open' ? '모집중' : meeting.status === 'full' ? '모집완료' : '모집종료'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4 line-clamp-2">{meeting.description}</p>
              
              <div className="space-y-2 text-sm text-gray-600 mb-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {meeting.date} {meeting.time}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {meeting.location}
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  {meeting.currentParticipants}/{meeting.maxParticipants}명
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="outline">{meeting.level}</Badge>
                <Badge variant="outline">{meeting.fee}</Badge>
                {meeting.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">
                  주최자: {meeting.organizer}
                </span>
                {isLoggedIn && meeting.status === 'open' && (
                  <Button 
                    size="sm" 
                    onClick={() => handleJoinMeeting(meeting.id)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    참여하기
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};