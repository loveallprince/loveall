import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Phone, Clock, ExternalLink, Star, AlertCircle, Settings, RefreshCw, CheckCircle, Navigation, Info, Globe, Wifi, WifiOff, Zap, Copy, ExternalLinkIcon, Monitor, Shield, Key, Link, Eye } from 'lucide-react';

interface TennisCourt {
  id: string;
  name: string;
  address: string;
  phone: string;
  openHours: string;
  courtType: string;
  reservationUrl: string;
  rating: number;
  reviewCount: number;
  facilities: string[];
  lat: number;
  lng: number;
}

interface NaverMapProps {
  tennisCourtData: TennisCourt[];
  selectedCourt: TennisCourt | null;
  onCourtSelect: (court: TennisCourt) => void;
}

// 지도 API 타입 선언
declare global {
  interface Window {
    naver: any;
    L: any;
  }
}

// 네이버 지도 API 로딩 상태
type LoadingState = 
  | 'initial'
  | 'script-loading'
  | 'script-loaded'
  | 'api-checking'
  | 'api-ready'
  | 'auth-failed'
  | 'network-failed'
  | 'timeout'
  | 'fallback-loading'
  | 'fallback-ready'
  | 'complete';

export const NaverMap: React.FC<NaverMapProps> = ({ 
  tennisCourtData, 
  selectedCourt, 
  onCourtSelect 
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [markers, setMarkers] = useState<any[]>([]);
  const [infoWindows, setInfoWindows] = useState<any[]>([]);
  const [loadingState, setLoadingState] = useState<LoadingState>('initial');
  const [mapType, setMapType] = useState<'naver' | 'leaflet'>('naver');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [debugLogs, setDebugLogs] = useState<string[]>([]);
  const [showDebugInfo, setShowDebugInfo] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [currentDomain, setCurrentDomain] = useState<string>('');
  const [showDomainInfo, setShowDomainInfo] = useState(false);

  // ✅ 네이버 지도 API 클라이언트 ID
  const NAVER_MAP_CLIENT_ID = "t7xrgau2p1";

  // 현재 도메인 감지
  useEffect(() => {
    const domain = window.location.origin;
    setCurrentDomain(domain);
    addLog(`현재 실행 도메인: ${domain}`, 'info');
  }, []);

  // Figma Make 환경을 위한 포괄적인 URL 패턴 생성
  const generateUrlPatterns = useCallback(() => {
    const current = window.location.origin;
    const hostname = window.location.hostname;
    
    // Figma Make 환경에서 가능한 모든 패턴
    const patterns = [
      // 현재 도메인
      current,
      `${current}/*`,
      
      // 프로토콜 와일드카드
      `*://${hostname}`,
      `*://${hostname}/*`,
      
      // Figma 관련 도메인들
      'https://figma.com',
      'https://*.figma.com',
      'https://www.figma.com',
      'https://*.figma.com/*',
      'https://figma.com/*',
      
      // 포괄적 와일드카드
      '*://figma.com',
      '*://figma.com/*',
      '*://*.figma.com',
      '*://*.figma.com/*',
      
      // 서브도메인 포함
      `*://*.${hostname.split('.').slice(-2).join('.')}`,
      `*://*.${hostname.split('.').slice(-2).join('.')}/*`,
      
      // localhost 패턴 (개발용)
      'http://localhost:*',
      'https://localhost:*',
      '*://localhost:*',
      
      // 일반적인 개발 도메인 패턴
      '*://*.github.io',
      '*://*.github.io/*',
      '*://*.vercel.app',
      '*://*.vercel.app/*',
      '*://*.netlify.app',
      '*://*.netlify.app/*'
    ];
    
    // 중복 제거
    return [...new Set(patterns)];
  }, []);

  // 디버그 로그 추가 함수
  const addLog = useCallback((message: string, type: 'info' | 'error' | 'success' = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${type.toUpperCase()}: ${message}`;
    console.log(logEntry);
    setDebugLogs(prev => [...prev.slice(-19), logEntry]); // 최근 20개만 유지
  }, []);

  // 네이버 지도 API 스크립트 로드 (완전히 새로운 접근법)
  const loadNaverMapScript = useCallback((): Promise<void> => {
    return new Promise((resolve, reject) => {
      // 이미 로드된 경우 체크
      if (window.naver?.maps?.Map) {
        addLog('네이버 지도 API가 이미 로드되어 있습니다', 'success');
        resolve();
        return;
      }

      addLog(`네이버 지도 API 스크립트 로드 시작 (도메인: ${currentDomain})`);
      setLoadingState('script-loading');

      // 기존 스크립트 제거 (새로 시작)
      const existingScript = document.querySelector(`script[src*="oapi.map.naver.com"]`);
      if (existingScript) {
        existingScript.remove();
        addLog('기존 네이버 지도 스크립트 제거됨');
      }

      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = `https://oapi.map.naver.com/openapi/v3/maps.js?ncpClientId=${NAVER_MAP_CLIENT_ID}`;
      script.async = true;
      script.defer = true;
      
      let timeoutId: number;
      let resolved = false;
      
      const cleanup = () => {
        if (timeoutId) clearTimeout(timeoutId);
      };
      
      const resolveOnce = (message: string) => {
        if (!resolved) {
          resolved = true;
          cleanup();
          addLog(message, 'success');
          setLoadingState('script-loaded');
          resolve();
        }
      };
      
      const rejectOnce = (error: Error) => {
        if (!resolved) {
          resolved = true;
          cleanup();
          addLog(`실패: ${error.message}`, 'error');
          reject(error);
        }
      };

      // 스크립트 로드 완료 감지
      script.onload = () => {
        addLog('네이버 지도 스크립트 파일 로드 완료');
        setLoadingState('api-checking');
        
        // API 객체 준비 상태 확인 (더 정교한 방식)
        let checkCount = 0;
        const maxChecks = 50; // 5초 동안 체크
        
        const checkApiReady = () => {
          checkCount++;
          addLog(`API 준비 상태 확인 중... (${checkCount}/${maxChecks})`);
          
          try {
            // 더 구체적인 API 준비 상태 확인
            if (window.naver && 
                window.naver.maps && 
                typeof window.naver.maps.Map === 'function' &&
                typeof window.naver.maps.Marker === 'function' &&
                typeof window.naver.maps.LatLng === 'function' &&
                window.naver.maps.Event &&
                typeof window.naver.maps.Event.addListener === 'function') {
              
              // 추가 검증: 실제 맵 생성 테스트
              try {
                const testDiv = document.createElement('div');
                testDiv.style.width = '1px';
                testDiv.style.height = '1px';
                testDiv.style.position = 'absolute';
                testDiv.style.left = '-9999px';
                document.body.appendChild(testDiv);
                
                const testMap = new window.naver.maps.Map(testDiv, {
                  center: new window.naver.maps.LatLng(37.5665, 126.9780),
                  zoom: 10
                });
                
                if (testMap) {
                  document.body.removeChild(testDiv);
                  resolveOnce('네이버 지도 API 완전히 준비됨 (검증 완료)');
                  return;
                }
              } catch (testError: any) {
                addLog(`API 테스트 실패: ${testError.message}`, 'error');
                if (testError.message.includes('Unauthorized') || 
                    testError.message.includes('Authentication') ||
                    testError.message.includes('Forbidden') ||
                    testError.message.includes('Invalid') ||
                    testError.message.includes('CORS')) {
                  rejectOnce(new Error(`네이버 지도 API 인증 실패 - 웹 서비스 URL 설정 필요 (현재 도메인: ${currentDomain})`));
                  return;
                }
              }
            }
            
            // 최대 체크 횟수 도달
            if (checkCount >= maxChecks) {
              rejectOnce(new Error('네이버 지도 API 준비 타임아웃'));
              return;
            }
            
            // 100ms 후 다시 체크
            setTimeout(checkApiReady, 100);
            
          } catch (checkError: any) {
            addLog(`API 체크 중 오류: ${checkError.message}`, 'error');
            if (checkError.message.includes('Unauthorized') || 
                checkError.message.includes('Authentication') ||
                checkError.message.includes('CORS')) {
              rejectOnce(new Error(`네이버 지도 API 인증 실패 - 도메인 불일치 (${currentDomain})`));
            } else {
              setTimeout(checkApiReady, 100);
            }
          }
        };
        
        checkApiReady();
      };
      
      script.onerror = (event) => {
        addLog(`네이버 지도 스크립트 로드 실패 (도메인: ${currentDomain})`, 'error');
        rejectOnce(new Error(`네이버 지도 API 스크립트 로드 실패 - 네트워크 오류 또는 도메인 인증 문제`));
      };
      
      // 전역 오류 감지
      const originalOnError = window.onerror;
      window.onerror = (message, source, lineno, colno, error) => {
        if (source?.includes('oapi.map.naver.com')) {
          addLog(`네이버 지도 API 오류 감지: ${message}`, 'error');
          if (message.toString().includes('Unauthorized') || 
              message.toString().includes('Authentication') ||
              message.toString().includes('Forbidden') ||
              message.toString().includes('CORS')) {
            rejectOnce(new Error(`네이버 지도 API 인증 실패 - 도메인 설정 문제 (${currentDomain})`));
          }
        }
        if (originalOnError) {
          return originalOnError(message, source, lineno, colno, error);
        }
        return false;
      };
      
      // 8초 타임아웃
      timeoutId = window.setTimeout(() => {
        window.onerror = originalOnError;
        rejectOnce(new Error(`네이버 지도 API 로드 타임아웃 (8초) - 도메인 인증 실패일 가능성 높음 (${currentDomain})`));
      }, 8000);
      
      document.head.appendChild(script);
      addLog(`네이버 지도 스크립트 요청됨: ${script.src}`);
    });
  }, [addLog, NAVER_MAP_CLIENT_ID, currentDomain]);

  // Leaflet 지도 API 로드 (대체용)
  const loadLeafletScript = useCallback((): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (window.L) {
        addLog('Leaflet이 이미 로드되어 있습니다', 'success');
        resolve();
        return;
      }

      addLog('Leaflet (대체 지도) 로드 시작');
      setLoadingState('fallback-loading');

      const cssLink = document.createElement('link');
      cssLink.rel = 'stylesheet';
      cssLink.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      cssLink.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
      cssLink.crossOrigin = '';
      document.head.appendChild(cssLink);

      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
      script.crossOrigin = '';
      
      script.onload = () => {
        addLog('Leaflet 스크립트 로드 완료');
        setTimeout(() => {
          if (window.L && typeof window.L.map === 'function') {
            addLog('Leaflet API 준비 완료', 'success');
            setLoadingState('fallback-ready');
            resolve();
          } else {
            reject(new Error('Leaflet API 초기화 실패'));
          }
        }, 100);
      };
      
      script.onerror = () => {
        addLog('Leaflet 스크립트 로드 실패', 'error');
        reject(new Error('Leaflet 스크립트 로드 실패'));
      };
      
      document.head.appendChild(script);
    });
  }, [addLog]);

  // 지도 초기화 메인 함수
  const initializeMap = useCallback(async () => {
    try {
      setLoadingState('initial');
      setErrorMessage('');
      addLog('=== Love All 지도 서비스 초기화 시작 ===');
      addLog(`시도 횟수: ${retryCount + 1}`);
      addLog(`현재 실행 도메인: ${currentDomain}`);
      
      // 1단계: 네이버 지도 API 시도
      try {
        addLog('1단계: 네이버 지도 API 연결 시도');
        await loadNaverMapScript();
        
        addLog('네이버 지도 API 로드 성공!', 'success');
        setMapType('naver');
        setLoadingState('api-ready');
        
      } catch (naverError: any) {
        addLog(`네이버 지도 실패: ${naverError.message}`, 'error');
        setErrorMessage(naverError.message);
        
        // 도메인 관련 오류인지 확인
        if (naverError.message.includes('인증') || 
            naverError.message.includes('도메인') ||
            naverError.message.includes('CORS')) {
          setLoadingState('auth-failed');
        }
        
        // 2단계: Leaflet 대체 지도로 전환
        addLog('2단계: 대체 지도 (Leaflet)로 전환');
        await loadLeafletScript();
        
        addLog('대체 지도 로드 성공!', 'success');
        setMapType('leaflet');
        setLoadingState('fallback-ready');
      }
      
      setLoadingState('complete');
      addLog('=== 지도 서비스 초기화 완료 ===', 'success');
      
    } catch (error: any) {
      addLog(`모든 지도 서비스 로드 실패: ${error.message}`, 'error');
      setErrorMessage('지도 서비스를 불러올 수 없습니다. 네트워크 연결을 확인해주세요.');
      setLoadingState('network-failed');
    }
  }, [loadNaverMapScript, loadLeafletScript, addLog, retryCount, currentDomain]);

  // 네이버 지도 재시도
  const retryNaverMap = useCallback(async () => {
    setRetryCount(prev => prev + 1);
    addLog(`네이버 지도 재시도 시작 (${retryCount + 2}번째) - 도메인: ${currentDomain}`);
    
    // 기존 상태 초기화
    setErrorMessage('');
    setMap(null);
    markers.forEach(marker => marker?.setMap?.(null));
    setMarkers([]);
    setInfoWindows([]);
    
    await initializeMap();
  }, [initializeMap, retryCount, markers, currentDomain]);

  // 초기 로드
  useEffect(() => {
    if (currentDomain) {
      initializeMap();
    }
  }, [currentDomain]);

  // 네이버 지도 초기화
  const initNaverMap = useCallback(() => {
    if (!mapRef.current || !window.naver?.maps) {
      addLog('네이버 지도 초기화 조건 미충족', 'error');
      return;
    }

    try {
      addLog('네이버 지도 인스턴스 생성 시작');
      
      const mapOptions = {
        center: new window.naver.maps.LatLng(37.5665, 126.9780), // 서울시청
        zoom: 11,
        mapTypeControl: true,
        mapTypeControlOptions: {
          style: window.naver.maps.MapTypeControlStyle?.BUTTON,
          position: window.naver.maps.Position?.TOP_RIGHT
        },
        zoomControl: true,
        zoomControlOptions: {
          position: window.naver.maps.Position?.TOP_LEFT
        },
        scaleControl: false,
        logoControl: true,
        logoControlOptions: {
          position: window.naver.maps.Position?.BOTTOM_LEFT
        }
      };

      const mapInstance = new window.naver.maps.Map(mapRef.current, mapOptions);
      
      // 지도 로드 완료 이벤트 대기
      window.naver.maps.Event.addListener(mapInstance, 'init', () => {
        addLog('네이버 지도 초기화 완료!', 'success');
        setMap(mapInstance);
      });

    } catch (error: any) {
      addLog(`네이버 지도 초기화 실패: ${error.message}`, 'error');
      
      // 인증 오류인 경우 명확히 표시
      if (error.message.includes('Unauthorized') || 
          error.message.includes('Authentication') ||
          error.message.includes('Forbidden')) {
        setErrorMessage(`네이버 지도 API 인증 실패 - 웹 서비스 URL에 ${currentDomain}을 등록해주세요`);
        setLoadingState('auth-failed');
      } else {
        setErrorMessage(`네이버 지도 초기화 실패: ${error.message}`);
      }
    }
  }, [addLog, currentDomain]);

  // Leaflet 지도 초기화
  const initLeafletMap = useCallback(() => {
    if (!mapRef.current || !window.L) {
      addLog('Leaflet 지도 초기화 조건 미충족', 'error');
      return;
    }

    try {
      addLog('Leaflet 지도 인스턴스 생성 시작');
      
      const mapInstance = window.L.map(mapRef.current, {
        center: [37.5665, 126.9780],
        zoom: 11,
        zoomControl: true,
        attributionControl: true
      });

      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors | Love All',
        maxZoom: 19,
        subdomains: ['a', 'b', 'c']
      }).addTo(mapInstance);

      addLog('Leaflet 지도 초기화 완료!', 'success');
      setMap(mapInstance);

    } catch (error: any) {
      addLog(`Leaflet 지도 초기화 실패: ${error.message}`, 'error');
      setErrorMessage(`지도 초기화 실패: ${error.message}`);
    }
  }, [addLog]);

  // 지도 인스턴스 생성
  useEffect(() => {
    if (loadingState !== 'complete' || !mapRef.current) return;

    if (mapType === 'naver' && window.naver?.maps) {
      initNaverMap();
    } else if (mapType === 'leaflet' && window.L) {
      initLeafletMap();
    }
  }, [loadingState, mapType, initNaverMap, initLeafletMap]);

  // 네이버 지도 마커 생성
  const createNaverMarkers = useCallback(() => {
    if (!map || !window.naver?.maps || !tennisCourtData.length) return;

    addLog(`네이버 지도 마커 생성 시작 (${tennisCourtData.length}개)`);

    // 기존 마커 정리
    markers.forEach(marker => marker?.setMap?.(null));
    infoWindows.forEach(infoWindow => infoWindow?.close?.());

    const newMarkers: any[] = [];
    const newInfoWindows: any[] = [];

    tennisCourtData.forEach((court, index) => {
      try {
        if (!court.lat || !court.lng || isNaN(court.lat) || isNaN(court.lng)) {
          addLog(`유효하지 않은 좌표: ${court.name} (${court.lat}, ${court.lng})`);
          return;
        }

        const isSelected = selectedCourt?.id === court.id;
        
        const marker = new window.naver.maps.Marker({
          position: new window.naver.maps.LatLng(court.lat, court.lng),
          map: map,
          title: court.name,
          icon: {
            content: `
              <div style="
                background: linear-gradient(135deg, ${isSelected ? '#dc2626' : '#16a34a'}, ${isSelected ? '#b91c1c' : '#15803d'});
                color: white;
                padding: 12px 16px;
                border-radius: 30px;
                font-weight: bold;
                font-size: 14px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.3);
                white-space: nowrap;
                border: 3px solid white;
                text-align: center;
                min-width: 80px;
                transform: ${isSelected ? 'scale(1.15)' : 'scale(1)'};
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                position: relative;
              ">
                <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                  <span style="font-size: 16px;">🎾</span>
                  <span>${court.name.length > 6 ? court.name.substring(0, 6) + '...' : court.name}</span>
                </div>
                ${isSelected ? '<div style="position: absolute; top: -8px; right: -8px; background: #fbbf24; color: #92400e; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: bold;">✓</div>' : ''}
              </div>
            `,
            size: new window.naver.maps.Size(160, 50),
            anchor: new window.naver.maps.Point(80, 50)
          }
        });

        // 고급 정보창 내용
        const infoWindowContent = `
          <div style="
            padding: 24px; 
            min-width: 350px; 
            max-width: 400px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            border: 1px solid rgba(0,0,0,0.05);
          ">
            <!-- 헤더 -->
            <div style="text-align: center; margin-bottom: 20px;">
              <div style="
                display: inline-flex;
                align-items: center;
                gap: 8px;
                background: linear-gradient(135deg, #16a34a, #15803d);
                color: white;
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: 600;
                margin-bottom: 12px;
              ">
                <span>🎾</span>
                <span>Love All 테니스장</span>
              </div>
              
              <h3 style="
                margin: 0 0 12px 0; 
                font-size: 22px; 
                font-weight: 700; 
                color: #1f2937; 
                line-height: 1.3;
              ">
                ${court.name}
              </h3>
              
              <div style="display: flex; align-items: center; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <span style="
                  background: linear-gradient(135deg, #3b82f6, #1d4ed8); 
                  color: white; 
                  padding: 6px 14px; 
                  border-radius: 16px; 
                  font-size: 12px; 
                  font-weight: 600;
                ">
                  ${court.courtType}
                </span>
                <span style="
                  display: flex; 
                  align-items: center; 
                  gap: 6px; 
                  font-size: 15px; 
                  background: #fef3cd; 
                  padding: 6px 12px; 
                  border-radius: 16px; 
                  color: #92400e;
                  font-weight: 600;
                ">
                  ⭐ ${court.rating} <span style="color: #b45309;">(${court.reviewCount})</span>
                </span>
              </div>
            </div>
            
            <!-- 정보 섹션 -->
            <div style="
              background: white; 
              padding: 20px; 
              border-radius: 16px; 
              margin-bottom: 20px; 
              box-shadow: 0 4px 16px rgba(0,0,0,0.06);
              border: 1px solid #f1f5f9;
            ">
              <div style="
                font-size: 15px; 
                color: #475569; 
                margin-bottom: 12px; 
                display: flex; 
                align-items: flex-start; 
                gap: 12px;
                line-height: 1.5;
              ">
                <span style="color: #16a34a; font-size: 18px; margin-top: 2px;">📍</span>
                <span style="font-weight: 500;">${court.address}</span>
              </div>
              <div style="
                font-size: 15px; 
                color: #475569; 
                margin-bottom: 12px; 
                display: flex; 
                align-items: center; 
                gap: 12px;
              ">
                <span style="color: #3b82f6; font-size: 18px;">📞</span>
                <span style="font-weight: 500;">${court.phone}</span>
              </div>
              <div style="
                font-size: 15px; 
                color: #475569; 
                display: flex; 
                align-items: center; 
                gap: 12px;
              ">
                <span style="color: #f59e0b; font-size: 18px;">🕒</span>
                <span style="font-weight: 500;">${court.openHours}</span>
              </div>
            </div>
            
            <!-- 시설 정보 -->
            <div style="
              display: flex; 
              gap: 8px; 
              margin-bottom: 20px; 
              flex-wrap: wrap; 
              justify-content: center;
            ">
              ${court.facilities?.slice(0, 4).map(facility => 
                `<span style="
                  background: #f1f5f9; 
                  padding: 6px 12px; 
                  border-radius: 12px; 
                  font-size: 12px; 
                  color: #475569; 
                  border: 1px solid #e2e8f0;
                  font-weight: 500;
                ">${facility}</span>`
              ).join('') || ''}
            </div>
            
            <!-- 예약 버튼 -->
            <button 
              onclick="window.open('${court.reservationUrl}', '_blank')"
              style="
                background: linear-gradient(135deg, #16a34a, #15803d);
                color: white;
                padding: 16px 28px;
                border: none;
                border-radius: 16px;
                font-size: 16px;
                font-weight: 700;
                cursor: pointer;
                width: 100%;
                box-shadow: 0 8px 24px rgba(22, 163, 74, 0.3);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
              "
              onmouseover="
                this.style.background='linear-gradient(135deg, #15803d, #166534)'; 
                this.style.transform='translateY(-3px)'; 
                this.style.boxShadow='0 12px 32px rgba(22, 163, 74, 0.4)'
              "
              onmouseout="
                this.style.background='linear-gradient(135deg, #16a34a, #15803d)'; 
                this.style.transform='translateY(0)'; 
                this.style.boxShadow='0 8px 24px rgba(22, 163, 74, 0.3)'
              "
            >
              <span style="font-size: 20px;">🎾</span>
              <span>예약하기</span>
            </button>
          </div>
        `;

        const infoWindow = new window.naver.maps.InfoWindow({
          content: infoWindowContent,
          maxWidth: 420,
          backgroundColor: 'transparent',
          borderColor: 'transparent',
          borderWidth: 0,
          anchorSize: new window.naver.maps.Size(0, 0),
          pixelOffset: new window.naver.maps.Point(0, -10)
        });

        // 마커 클릭 이벤트
        window.naver.maps.Event.addListener(marker, 'click', () => {
          addLog(`마커 클릭: ${court.name}`);
          onCourtSelect(court);
          
          // 다른 정보창 닫기
          newInfoWindows.forEach(iw => iw?.close?.());
          
          // 현재 정보창 토글
          if (infoWindow.getMap()) {
            infoWindow.close();
          } else {
            infoWindow.open(map, marker);
            map.setCenter(marker.getPosition());
            map.setZoom(15);
          }
        });

        newMarkers.push(marker);
        newInfoWindows.push(infoWindow);

      } catch (error: any) {
        addLog(`마커 생성 실패 (${court.name}): ${error.message}`, 'error');
      }
    });

    setMarkers(newMarkers);
    setInfoWindows(newInfoWindows);
    
    addLog(`네이버 지도 마커 생성 완료 (${newMarkers.length}개)`, 'success');

    // 지도 뷰 조정
    if (newMarkers.length > 0) {
      try {
        const bounds = new window.naver.maps.LatLngBounds();
        newMarkers.forEach(marker => {
          bounds.extend(marker.getPosition());
        });
        map.fitBounds(bounds, { padding: 50, maxZoom: 13 });
        addLog('지도 뷰 자동 조정 완료');
      } catch (error: any) {
        addLog(`지도 뷰 조정 실패: ${error.message}`, 'error');
      }
    }
  }, [map, tennisCourtData, selectedCourt, onCourtSelect, markers, infoWindows, addLog]);

  // Leaflet 마커 생성
  const createLeafletMarkers = useCallback(() => {
    if (!map || !window.L || !tennisCourtData.length) return;

    addLog(`Leaflet 지도 마커 생성 시작 (${tennisCourtData.length}개)`);

    // 기존 마커 제거
    markers.forEach(marker => marker?.remove?.());
    const newMarkers: any[] = [];

    tennisCourtData.forEach((court) => {
      try {
        if (!court.lat || !court.lng || isNaN(court.lat) || isNaN(court.lng)) return;

        const isSelected = selectedCourt?.id === court.id;

        const marker = window.L.marker([court.lat, court.lng], {
          icon: window.L.divIcon({
            html: `
              <div style="
                background: linear-gradient(135deg, ${isSelected ? '#dc2626' : '#16a34a'}, ${isSelected ? '#b91c1c' : '#15803d'});
                color: white;
                padding: 12px 16px;
                border-radius: 30px;
                font-weight: bold;
                font-size: 14px;
                box-shadow: 0 8px 25px rgba(0,0,0,0.3);
                white-space: nowrap;
                border: 3px solid white;
                text-align: center;
                min-width: 80px;
                transform: ${isSelected ? 'scale(1.1)' : 'scale(1)'};
                transition: all 0.3s ease;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
              ">
                🎾 ${court.name.length > 6 ? court.name.substring(0, 6) + '...' : court.name}
              </div>
            `,
            className: 'custom-leaflet-marker',
            iconSize: [160, 50],
            iconAnchor: [80, 50]
          })
        }).addTo(map);

        marker.bindPopup(`
          <div style="padding: 20px; min-width: 280px; font-family: -apple-system, BlinkMacSystemFont, sans-serif;">
            <div style="text-align: center; margin-bottom: 15px;">
              <h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: bold; color: #1f2937;">
                🎾 ${court.name}
              </h3>
              <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                <span style="background: #3b82f6; color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                  ${court.courtType}
                </span>
                <span style="background: #fef3cd; color: #92400e; padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: 600;">
                  ⭐ ${court.rating} (${court.reviewCount})
                </span>
              </div>
            </div>
            
            <div style="background: #f8fafc; padding: 15px; border-radius: 12px; margin-bottom: 15px;">
              <div style="font-size: 14px; color: #475569; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                <span style="color: #16a34a;">📍</span>
                ${court.address}
              </div>
              <div style="font-size: 14px; color: #475569; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                <span style="color: #3b82f6;">📞</span>
                ${court.phone}
              </div>
              <div style="font-size: 14px; color: #475569; display: flex; align-items: center; gap: 8px;">
                <span style="color: #f59e0b;">🕒</span>
                ${court.openHours}
              </div>
            </div>
            
            <button onclick="window.open('${court.reservationUrl}', '_blank')" 
                    style="
                      background: linear-gradient(135deg, #16a34a, #15803d); 
                      color: white; 
                      padding: 12px 20px; 
                      border: none; 
                      border-radius: 12px; 
                      width: 100%; 
                      cursor: pointer; 
                      font-size: 14px; 
                      font-weight: 600;
                      box-shadow: 0 4px 12px rgba(22, 163, 74, 0.3);
                      transition: all 0.3s ease;
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      gap: 8px;
                    ">
              <span>🎾</span>
              <span>예약하기</span>
            </button>
          </div>
        `, {
          maxWidth: 350,
          className: 'custom-leaflet-popup'
        });

        marker.on('click', () => {
          onCourtSelect(court);
          map.setView([court.lat, court.lng], 15);
        });

        newMarkers.push(marker);

      } catch (error: any) {
        addLog(`Leaflet 마커 생성 실패 (${court.name}): ${error.message}`, 'error');
      }
    });

    setMarkers(newMarkers);
    addLog(`Leaflet 마커 생성 완료 (${newMarkers.length}개)`, 'success');

    // 지도 뷰 조정
    if (newMarkers.length > 0) {
      try {
        const group = new window.L.featureGroup(newMarkers);
        map.fitBounds(group.getBounds(), { padding: [30, 30], maxZoom: 13 });
        addLog('Leaflet 지도 뷰 자동 조정 완료');
      } catch (error: any) {
        addLog(`Leaflet 지도 뷰 조정 실패: ${error.message}`, 'error');
      }
    }
  }, [map, tennisCourtData, selectedCourt, onCourtSelect, markers, addLog]);

  // 마커 생성
  useEffect(() => {
    if (!map || !tennisCourtData.length) return;

    if (mapType === 'naver') {
      createNaverMarkers();
    } else {
      createLeafletMarkers();
    }
  }, [map, tennisCourtData, selectedCourt, mapType, createNaverMarkers, createLeafletMarkers]);

  // 선택된 테니스장으로 이동
  useEffect(() => {
    if (!map || !selectedCourt) return;

    try {
      const { lat, lng } = selectedCourt;
      if (!lat || !lng || isNaN(lat) || isNaN(lng)) return;

      addLog(`선택된 테니스장으로 이동: ${selectedCourt.name}`);

      if (mapType === 'naver' && window.naver?.maps) {
        const position = new window.naver.maps.LatLng(lat, lng);
        map.setCenter(position);
        map.setZoom(15);
      } else if (mapType === 'leaflet') {
        map.setView([lat, lng], 15, { animate: true, duration: 0.8 });
      }
    } catch (error: any) {
      addLog(`지도 이동 실패: ${error.message}`, 'error');
    }
  }, [map, selectedCourt, mapType, addLog]);

  // URL 복사 함수
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      addLog(`클립보드에 복사됨: ${text}`);
    });
  };

  // 로딩 상태 렌더링
  if (loadingState !== 'complete' && loadingState !== 'auth-failed' && loadingState !== 'network-failed') {
    const getLoadingMessage = () => {
      switch (loadingState) {
        case 'initial':
          return '지도 서비스 준비 중...';
        case 'script-loading':
          return '네이버 지도 API 연결 중...';
        case 'script-loaded':
          return '네이버 지도 API 로드됨';
        case 'api-checking':
          return '네이버 지도 API 준비 상태 확인 중...';
        case 'api-ready':
          return '네이버 지도 API 준비 완료!';
        case 'fallback-loading':
          return '대체 지도 서비스로 전환 중...';
        case 'fallback-ready':
          return '대체 지도 준비 완료!';
        default:
          return '로딩 중...';
      }
    };

    return (
      <Card className="h-[500px]">
        <CardContent className="h-full flex items-center justify-center">
          <div className="text-center">
            <div className="w-20 h-20 border-4 border-green-200 border-t-green-600 rounded-full animate-spin mx-auto mb-6"></div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Love All 지도 서비스</h3>
            <p className="text-gray-600 mb-2">{getLoadingMessage()}</p>
            
            {currentDomain && (
              <div className="text-sm text-gray-500 mb-4">
                현재 도메인: <code className="bg-gray-100 px-2 py-1 rounded">{currentDomain}</code>
              </div>
            )}
            
            <div className="flex items-center justify-center gap-2 text-sm">
              {loadingState.includes('naver') || loadingState === 'api-checking' || loadingState === 'api-ready' ? (
                <>
                  <Wifi className="w-4 h-4 text-blue-500 animate-pulse" />
                  <span className="text-gray-500">네이버 지도 API</span>
                </>
              ) : loadingState.includes('fallback') ? (
                <>
                  <Navigation className="w-4 h-4 text-orange-500 animate-pulse" />
                  <span className="text-gray-500">OpenStreetMap</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-green-500 animate-pulse" />
                  <span className="text-gray-500">초기화 중</span>
                </>
              )}
            </div>

            {/* 진행 표시 */}
            <div className="mt-4 w-64 mx-auto">
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-green-500 to-blue-500 transition-all duration-500 ease-out"
                  style={{
                    width: 
                      loadingState === 'script-loading' ? '20%' :
                      loadingState === 'script-loaded' ? '40%' :
                      loadingState === 'api-checking' ? '60%' :
                      loadingState === 'api-ready' ? '80%' :
                      loadingState === 'fallback-loading' ? '50%' :
                      loadingState === 'fallback-ready' ? '90%' :
                      '10%'
                  }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // 오류 상태 렌더링
  if (loadingState === 'auth-failed' || loadingState === 'network-failed' || errorMessage) {
    const urlPatterns = generateUrlPatterns();
    
    return (
      <Card className="h-[500px]">
        <CardContent className="h-full flex items-center justify-center">
          <div className="text-center max-w-5xl">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              네이버 지도 API 도메인 인증 실패
            </h3>

            {/* 현재 도메인 정보 */}
            <div className="bg-blue-50 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Eye className="w-5 h-5 text-blue-600" />
                <h4 className="font-semibold text-blue-800">현재 실행 도메인</h4>
              </div>
              <div className="flex items-center justify-center gap-2 bg-white rounded px-4 py-2">
                <code className="text-lg text-blue-800 font-mono">{currentDomain}</code>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => copyToClipboard(currentDomain)}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
              <p className="text-sm text-blue-700 mt-2">
                ⚠️ Figma Make는 매번 다른 도메인에서 실행됩니다. 아래 포괄적인 URL 패턴을 등록하세요.
              </p>
            </div>

            {/* 상세 오류 정보 */}
            <div className="bg-red-50 rounded-xl p-6 text-left mb-6">
              <h4 className="font-semibold text-red-800 mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                네이버 클라우드 플랫폼 - 웹 서비스 URL 등록 가이드
              </h4>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Client ID 정보 */}
                <div className="bg-white rounded-lg p-4 border-l-4 border-blue-400">
                  <div className="flex items-center gap-2 mb-3">
                    <Key className="w-4 h-4 text-blue-600" />
                    <h5 className="font-medium text-blue-800">Client ID</h5>
                  </div>
                  <div className="flex items-center gap-2 bg-gray-100 rounded px-3 py-2">
                    <code className="text-sm flex-1">{NAVER_MAP_CLIENT_ID}</code>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => copyToClipboard(NAVER_MAP_CLIENT_ID)}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {/* 중요한 URL 패턴 */}
                <div className="bg-white rounded-lg p-4 border-l-4 border-orange-400">
                  <div className="flex items-center gap-2 mb-3">
                    <Globe className="w-4 h-4 text-orange-600" />
                    <h5 className="font-medium text-orange-800">필수 URL 패턴</h5>
                  </div>
                  <div className="space-y-2">
                    {[currentDomain, `${currentDomain}/*`].map((url) => (
                      <div key={url} className="flex items-center gap-2 bg-orange-100 rounded px-3 py-2">
                        <code className="text-xs flex-1 font-bold text-orange-800">{url}</code>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => copyToClipboard(url)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 포괄적인 URL 패턴 목록 */}
              <div className="mt-6 bg-green-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-medium text-green-800 flex items-center gap-2">
                    <Link className="w-4 h-4" />
                    Figma Make용 포괄적 URL 패턴 ({urlPatterns.length}개)
                  </h5>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowDomainInfo(!showDomainInfo)}
                  >
                    {showDomainInfo ? '접기' : '모두 보기'}
                  </Button>
                </div>
                
                <p className="text-sm text-green-700 mb-3">
                  아래 URL들을 네이버 클라우드 플랫폼의 <strong>웹 서비스 URL</strong>에 <strong>각각 별도 줄에</strong> 추가하세요:
                </p>
                
                <div className={`grid grid-cols-1 md:grid-cols-2 gap-2 ${!showDomainInfo ? 'max-h-32 overflow-hidden' : ''}`}>
                  {(showDomainInfo ? urlPatterns : urlPatterns.slice(0, 8)).map((url) => (
                    <div key={url} className="flex items-center gap-2 bg-white rounded px-3 py-2 border border-green-200">
                      <code className="text-xs flex-1">{url}</code>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => copyToClipboard(url)}
                        className="h-6 w-6 p-0"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </div>
                
                {!showDomainInfo && urlPatterns.length > 8 && (
                  <div className="text-center mt-2">
                    <p className="text-xs text-green-600">
                      ...그리고 {urlPatterns.length - 8}개 더 (모두 보기 클릭)
                    </p>
                  </div>
                )}
              </div>

              {/* 설정 단계 */}
              <div className="mt-6 bg-yellow-50 rounded-lg p-4">
                <h5 className="font-medium text-yellow-800 mb-3 flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  설정 단계 (순서대로 진행하세요)
                </h5>
                <ol className="text-sm text-yellow-700 space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</span>
                    <span><strong>네이버 클라우드 플랫폼 콘솔</strong>에 로그인</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</span>
                    <span><strong>AI·NAVER API → Application</strong> 메뉴로 이동</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</span>
                    <span>해당 애플리케이션 <strong>({NAVER_MAP_CLIENT_ID})</strong> 선택</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">4</span>
                    <span><strong>서비스 환경 → Web Service URL</strong> 설정 페이지로 이동</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">5</span>
                    <span>위의 URL 패턴들을 <strong>각각 별도 줄에 추가</strong> (최소 10개 이상 권장)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">6</span>
                    <span><strong>설정 저장 후 5-10분 대기</strong> (반영 시간 필요)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-yellow-200 text-yellow-800 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">7</span>
                    <span>아래 <strong>"네이버 지도 재시도"</strong> 버튼 클릭</span>
                  </li>
                </ol>
              </div>
            </div>

            {/* 액션 버튼들 */}
            <div className="flex gap-3 justify-center flex-wrap mb-4">
              <Button 
                onClick={retryNaverMap} 
                className="bg-blue-600 hover:bg-blue-700"
                disabled={loadingState !== 'complete'}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                네이버 지도 재시도 {retryCount > 0 && `(${retryCount + 1}번째)`}
              </Button>
              
              <Button 
                variant="outline"
                onClick={() => window.open('https://console.ncloud.com/naver-service/application', '_blank')}
              >
                <ExternalLinkIcon className="w-4 h-4 mr-2" />
                네이버 클라우드 콘솔
              </Button>
              
              <Button 
                variant="outline"
                onClick={() => setShowDebugInfo(!showDebugInfo)}
              >
                <Monitor className="w-4 h-4 mr-2" />
                디버그 정보 {showDebugInfo ? '숨기기' : '보기'}
              </Button>
            </div>

            {/* 디버그 정보 */}
            {showDebugInfo && (
              <details className="text-left">
                <summary className="cursor-pointer font-medium text-gray-700 mb-3">
                  🔍 상세 디버그 로그 ({debugLogs.length}개)
                </summary>
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg text-xs font-mono max-h-64 overflow-y-auto">
                  {debugLogs.length > 0 ? (
                    debugLogs.map((log, index) => (
                      <div key={index} className="mb-1">{log}</div>
                    ))
                  ) : (
                    <div className="text-gray-500">로그가 없습니다.</div>
                  )}
                </div>
              </details>
            )}

            {/* 현재 오류 메시지 */}
            {errorMessage && (
              <div className="mt-4 p-3 bg-red-100 rounded-lg text-left">
                <p className="text-sm text-red-700">
                  <strong>현재 오류:</strong> {errorMessage}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // 정상 지도 렌더링
  return (
    <Card className="h-[500px]">
      <CardContent className="p-0 h-full relative">
        <div ref={mapRef} className="w-full h-full rounded-lg" style={{ minHeight: '500px' }} />
        
        {/* 지도 상태 표시 */}
        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm rounded-xl p-3 shadow-xl z-10 border border-white/20">
          <div className="flex items-center gap-2 text-sm">
            {mapType === 'naver' ? (
              <>
                <CheckCircle className="w-5 h-5 text-green-500" />
                <div className="flex items-center gap-2">
                  <span className="text-gray-700 font-semibold">네이버 지도</span>
                  <Badge className="bg-green-100 text-green-800 text-xs font-medium">✅ 연결됨</Badge>
                </div>
              </>
            ) : (
              <>
                <Navigation className="w-5 h-5 text-blue-500" />
                <div className="flex items-center gap-2">
                  <span className="text-gray-700 font-semibold">OpenStreetMap</span>
                  <Badge className="bg-blue-100 text-blue-800 text-xs font-medium">대체 서비스</Badge>
                </div>
              </>
            )}
          </div>
          {currentDomain && (
            <div className="text-xs text-gray-500 mt-1">
              도메인: <code className="bg-gray-100 px-1 rounded">{currentDomain.replace('https://', '').slice(0, 20)}...</code>
            </div>
          )}
        </div>

        {/* 네이버 지도 재시도 버튼 (OpenStreetMap 사용 중일 때) */}
        {mapType === 'leaflet' && (
          <div className="absolute top-20 right-4 z-10">
            <Button
              size="sm"
              variant="outline"
              onClick={retryNaverMap}
              className="bg-white/95 backdrop-blur-sm shadow-lg hover:bg-white border-white/20"
            >
              <RefreshCw className="w-3 h-3 mr-1" />
              네이버 지도 재시도
            </Button>
          </div>
        )}

        {/* 디버그 정보 버튼 */}
        <div className="absolute top-4 left-4 z-10">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowDebugInfo(!showDebugInfo)}
            className="bg-white/95 backdrop-blur-sm shadow-lg hover:bg-white border-white/20"
          >
            <Monitor className="w-3 h-3 mr-1" />
            디버그
          </Button>
        </div>

        {/* 디버그 패널 */}
        {showDebugInfo && (
          <div className="absolute top-16 left-4 bg-white/95 backdrop-blur-sm rounded-xl p-4 shadow-xl z-10 max-w-md border border-white/20">
            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Monitor className="w-4 h-4" />
              실시간 디버그 정보
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-600">상태:</span>
                <span className="font-medium">{loadingState}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">지도:</span>
                <span className="font-medium">{mapType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">마커:</span>
                <span className="font-medium">{markers.length}개</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">재시도:</span>
                <span className="font-medium">{retryCount}회</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">도메인:</span>
                <span className="font-medium font-mono text-xs">{currentDomain.slice(-20)}</span>
              </div>
            </div>
            <div className="mt-3 bg-gray-900 text-green-400 p-2 rounded text-xs font-mono max-h-32 overflow-y-auto">
              {debugLogs.slice(-5).map((log, index) => (
                <div key={index} className="mb-1">{log}</div>
              ))}
            </div>
          </div>
        )}

        {/* 사용법 안내 */}
        <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-xl p-3 shadow-lg z-10 border border-white/20">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">🎾</span>
            </div>
            <span className="text-gray-700 font-medium">마커를 클릭하여 상세 정보 확인</span>
          </div>
        </div>

        {/* 범례 */}
        <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm rounded-xl p-3 shadow-lg z-10 border border-white/20">
          <div className="flex items-center gap-3 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded-full"></div>
              <span className="text-gray-700 font-medium">테니스장</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded-full"></div>
              <span className="text-gray-700 font-medium">선택됨</span>
            </div>
          </div>
        </div>

        <style>{`
          .custom-leaflet-marker {
            filter: drop-shadow(0 6px 16px rgba(0,0,0,0.25));
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .custom-leaflet-marker:hover {
            filter: drop-shadow(0 8px 24px rgba(0,0,0,0.35));
            transform: scale(1.05) !important;
          }
          
          .custom-leaflet-popup .leaflet-popup-content-wrapper {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            padding: 0;
            border: 1px solid rgba(0,0,0,0.05);
          }
          
          .custom-leaflet-popup .leaflet-popup-content {
            margin: 0;
            padding: 0;
          }
          
          .custom-leaflet-popup .leaflet-popup-tip {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
          }
          
          .leaflet-control-zoom {
            border: none !important;
            box-shadow: 0 4px 16px rgba(0,0,0,0.1) !important;
            border-radius: 12px !important;
            overflow: hidden !important;
          }
          
          .leaflet-control-zoom a {
            background: rgba(255,255,255,0.95) !important;
            backdrop-filter: blur(10px) !important;
            border: none !important;
            color: #374151 !important;
            font-weight: bold !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
          }
          
          .leaflet-control-zoom a:hover {
            background: rgba(255,255,255,1) !important;
            color: #16a34a !important;
            transform: scale(1.05) !important;
          }
        `}</style>
      </CardContent>
    </Card>
  );
};