import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Star, MapPin, User, Calendar, Plus } from 'lucide-react';

interface Review {
  id: string;
  type: 'court' | 'meeting';
  targetName: string;
  rating: number;
  title: string;
  content: string;
  author: string;
  date: string;
  helpful: number;
  images?: string[];
  tags: string[];
}

interface ReviewSystemProps {
  isLoggedIn: boolean;
}

export const ReviewSystem: React.FC<ReviewSystemProps> = ({ isLoggedIn }) => {
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: '1',
      type: 'court',
      targetName: '올림픽공원 테니스장',
      rating: 5,
      title: '시설이 정말 좋아요!',
      content: '코트 상태도 깔끔하고 야간 조명도 밝아서 저녁 운동하기 좋습니다. 샤워실도 깨끗하고 주차장도 넓어요.',
      author: '테니스러버',
      date: '2025-07-05',
      helpful: 12,
      tags: ['시설 좋음', '야간 조명', '주차 편리']
    },
    {
      id: '2',
      type: 'meeting',
      targetName: '주말 테니스 모임',
      rating: 4,
      title: '즐거운 모임이었어요',
      content: '초보자도 편하게 참여할 수 있는 분위기였습니다. 다들 친절하고 실력도 비슷해서 재미있게 게임했어요.',
      author: '초보테니스',
      date: '2025-07-03',
      helpful: 8,
      tags: ['초보 환영', '친절한 분위기', '재미있음']
    },
    {
      id: '3',
      type: 'court',
      targetName: '한강시민공원 테니스장',
      rating: 3,
      title: '위치는 좋지만 예약이 어려워요',
      content: '한강변이라 경치는 좋지만 인기가 많아서 예약하기가 힘들어요. 코트 상태는 보통입니다.',
      author: '한강테니스',
      date: '2025-07-01',
      helpful: 5,
      tags: ['경치 좋음', '예약 어려움', '보통']
    }
  ]);

  const [filterType, setFilterType] = useState<'all' | 'court' | 'meeting'>('all');
  const [filterRating, setFilterRating] = useState('all');
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [newReview, setNewReview] = useState({
    type: 'court' as 'court' | 'meeting',
    targetName: '',
    rating: 5,
    title: '',
    content: ''
  });

  const filteredReviews = reviews.filter(review => {
    const typeMatch = filterType === 'all' || review.type === filterType;
    const ratingMatch = filterRating === 'all' || review.rating === parseInt(filterRating);
    return typeMatch && ratingMatch;
  });

  const handleCreateReview = () => {
    if (!newReview.targetName || !newReview.title || !newReview.content) {
      alert('모든 필드를 입력해주세요.');
      return;
    }

    const review: Review = {
      id: Date.now().toString(),
      type: newReview.type,
      targetName: newReview.targetName,
      rating: newReview.rating,
      title: newReview.title,
      content: newReview.content,
      author: '현재 사용자',
      date: new Date().toISOString().split('T')[0],
      helpful: 0,
      tags: []
    };

    setReviews([review, ...reviews]);
    setShowReviewDialog(false);
    setNewReview({
      type: 'court',
      targetName: '',
      rating: 5,
      title: '',
      content: ''
    });
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  const handleHelpful = (reviewId: string) => {
    setReviews(reviews.map(review => 
      review.id === reviewId 
        ? { ...review, helpful: review.helpful + 1 }
        : review
    ));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">리뷰 &amp; 후기</h1>
          <p className="text-gray-600 mt-2">테니스장과 모임에 대한 실제 이용 후기를 확인해보세요</p>
        </div>
        
        <div className="flex gap-4">
          <Select value={filterType} onValueChange={(value: 'all' | 'court' | 'meeting') => setFilterType(value)}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="타입 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체</SelectItem>
              <SelectItem value="court">테니스장</SelectItem>
              <SelectItem value="meeting">모임</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={filterRating} onValueChange={setFilterRating}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="별점 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체 별점</SelectItem>
              <SelectItem value="5">⭐⭐⭐⭐⭐</SelectItem>
              <SelectItem value="4">⭐⭐⭐⭐</SelectItem>
              <SelectItem value="3">⭐⭐⭐</SelectItem>
              <SelectItem value="2">⭐⭐</SelectItem>
              <SelectItem value="1">⭐</SelectItem>
            </SelectContent>
          </Select>
          
          {isLoggedIn && (
            <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  리뷰 작성
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]" aria-describedby="create-review-description">
                <DialogHeader>
                  <DialogTitle>리뷰 작성하기</DialogTitle>
                  <DialogDescription id="create-review-description">
                    테니스장이나 모임에 대한 솔직한 후기를 작성해 다른 사용자들에게 도움을 주세요.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="reviewType">리뷰 타입</Label>
                    <Select 
                      value={newReview.type} 
                      onValueChange={(value: 'court' | 'meeting') => setNewReview({...newReview, type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="리뷰 타입 선택" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="court">테니스장</SelectItem>
                        <SelectItem value="meeting">모임</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="targetName">
                      {newReview.type === 'court' ? '테니스장 이름' : '모임 이름'}
                    </Label>
                    <Input
                      id="targetName"
                      placeholder={newReview.type === 'court' ? '테니스장 이름' : '모임 이름'}
                      value={newReview.targetName}
                      onChange={(e) => setNewReview({...newReview, targetName: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="rating">별점</Label>
                    <div className="flex items-center gap-2 mt-1">
                      {Array.from({ length: 5 }, (_, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setNewReview({...newReview, rating: i + 1})}
                          className="p-1"
                        >
                          <Star
                            className={`w-6 h-6 ${i < newReview.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                          />
                        </button>
                      ))}
                      <span className="ml-2 text-sm text-gray-600">
                        {newReview.rating}점
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="title">리뷰 제목</Label>
                    <Input
                      id="title"
                      placeholder="리뷰 제목을 입력하세요"
                      value={newReview.title}
                      onChange={(e) => setNewReview({...newReview, title: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="content">리뷰 내용</Label>
                    <Textarea
                      id="content"
                      placeholder="자세한 이용 후기를 작성해주세요"
                      value={newReview.content}
                      onChange={(e) => setNewReview({...newReview, content: e.target.value})}
                      rows={4}
                    />
                  </div>
                  
                  <Button 
                    onClick={handleCreateReview}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    리뷰 작성하기
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <div className="space-y-6">
        {filteredReviews.map((review) => (
          <Card key={review.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback>{review.author.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{review.author}</span>
                      <Badge variant={review.type === 'court' ? 'default' : 'secondary'}>
                        {review.type === 'court' ? '테니스장' : '모임'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <span>{review.targetName}</span>
                      <span>•</span>
                      <span>{review.date}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {renderStars(review.rating)}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <h3 className="font-semibold text-lg mb-2">{review.title}</h3>
              <p className="text-gray-600 mb-4">{review.content}</p>
              
              {review.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                  {review.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleHelpful(review.id)}
                  className="text-gray-600 hover:text-green-600"
                >
                  👍 도움돼요 ({review.helpful})
                </Button>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span>리뷰 ID: {review.id}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};