import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { NaverMap } from './NaverMap';
import { seoulTennisCourts, courtsByDistrict, courtsByType, reservationTimeSlots } from '../data/seoulTennisCourts';
import { MapPin, Phone, Clock, ExternalLink, Filter, Search, Car, DollarSign, Users, Zap } from 'lucide-react';

interface TennisCourt {
  id: string;
  name: string;
  address: string;
  phone: string;
  openHours: string;
  courtType: string;
  reservationUrl: string;
  rating: number;
  reviewCount: number;
  facilities: string[];
  lat: number;
  lng: number;
  courtCount?: number;
  fee?: {
    daytime: string;
    nighttime: string;
  };
  parkingInfo?: string;
  district?: string;
  managementOrg?: string;
  additionalInfo?: string;
}

export const TennisCourtMap: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('all');
  const [selectedCourtType, setSelectedCourtType] = useState('all');
  const [selectedCourt, setSelectedCourt] = useState<TennisCourt | null>(null);
  const [showDetailedInfo, setShowDetailedInfo] = useState(false);

  // 서울시 공공 테니스장 데이터 사용
  const allCourts = seoulTennisCourts;

  const filteredCourts = allCourts.filter(court => {
    const matchesSearch = court.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         court.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         court.district.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDistrict = selectedDistrict === 'all' || court.district === selectedDistrict;
    const matchesType = selectedCourtType === 'all' || court.courtType === selectedCourtType;
    
    return matchesSearch && matchesDistrict && matchesType;
  });

  const handleCourtSelect = (court: TennisCourt) => {
    setSelectedCourt(court);
  };

  const handleSearch = () => {
    if (filteredCourts.length > 0) {
      setSelectedCourt(filteredCourts[0]);
    }
  };

  const handleReservation = (court: TennisCourt) => {
    // 서울시 공공예약 사이트로 이동
    window.open(court.reservationUrl, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">서울시 공공 테니스장 찾기</h1>
        <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <p className="font-semibold text-green-900">실시간 지도로 테니스장 위치 확인</p>
          </div>
          <p className="text-sm text-green-800">
            지도에서 테니스장을 클릭하면 상세 정보를 확인할 수 있습니다. 
            모든 예약은 <a href="https://yeyak.seoul.go.kr/web/main.do" target="_blank" rel="noopener noreferrer" className="underline font-medium text-green-700">서울시 공공예약 사이트</a>에서 진행됩니다.
          </p>
        </div>
        
        {/* Search and Filter */}
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="flex-1 flex gap-2">
            <Input
              placeholder="테니스장 이름, 주소, 지역으로 검색하세요..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-12"
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button 
              onClick={handleSearch}
              className="h-12 px-4 bg-green-600 hover:bg-green-700"
            >
              <Search className="w-5 h-5" />
            </Button>
          </div>
          <div className="flex gap-4">
            <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
              <SelectTrigger className="w-[180px] h-12">
                <SelectValue placeholder="지역 선택" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체 지역</SelectItem>
                <SelectItem value="송파구">송파구</SelectItem>
                <SelectItem value="성동구">성동구</SelectItem>
                <SelectItem value="영등포구">영등포구</SelectItem>
                <SelectItem value="동작구">동작구</SelectItem>
                <SelectItem value="마포구">마포구</SelectItem>
                <SelectItem value="서초구">서초구</SelectItem>
                <SelectItem value="용산구">용산구</SelectItem>
                <SelectItem value="중랑구">중랑구</SelectItem>
                <SelectItem value="강동구">강동구</SelectItem>
                <SelectItem value="과천시">과천시</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedCourtType} onValueChange={setSelectedCourtType}>
              <SelectTrigger className="w-[180px] h-12">
                <SelectValue placeholder="코트 타입" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체 코트</SelectItem>
                <SelectItem value="하드코트">하드코트</SelectItem>
                <SelectItem value="클레이코트">클레이코트</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Search Results Info */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <p className="text-gray-600">
              총 <span className="font-semibold text-green-600">{filteredCourts.length}</span>개의 테니스장이 검색되었습니다.
            </p>
            {selectedCourt && (
              <Badge variant="outline" className="bg-green-50 text-green-700">
                선택됨: {selectedCourt.name}
              </Badge>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDetailedInfo(!showDetailedInfo)}
          >
            {showDetailedInfo ? '간단히 보기' : '상세히 보기'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Map Section */}
        <div className="order-2 lg:order-1">
          <Card className="shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                서울시 공공 테니스장 지도
                <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800">
                  {filteredCourts.length}개 표시
                </Badge>
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                🎾 테니스장을 클릭하면 상세 정보를 확인할 수 있습니다
              </p>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative">
                <NaverMap
                  tennisCourtData={filteredCourts}
                  selectedCourt={selectedCourt}
                  onCourtSelect={handleCourtSelect}
                />
                {/* 지도 위 알림 메시지 */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-md z-10">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">🎾</span>
                    </div>
                    <span className="text-gray-700">실시간 지도 서비스</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tennis Courts List */}
        <div className="order-1 lg:order-2">
          <div className="space-y-4 max-h-[580px] overflow-y-auto custom-scrollbar">
            {filteredCourts.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">검색 결과가 없습니다.</p>
                  <p className="text-sm text-gray-500">다른 검색 조건을 시도해보세요.</p>
                </CardContent>
              </Card>
            ) : (
              filteredCourts.map((court) => (
                <Card 
                  key={court.id} 
                  className={`cursor-pointer transition-all hover:shadow-lg transform hover:scale-[1.01] ${
                    selectedCourt?.id === court.id ? 'ring-2 ring-green-500 bg-gradient-to-r from-green-50 to-blue-50 shadow-lg' : ''
                  }`}
                  onClick={() => handleCourtSelect(court)}
                >
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900">{court.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                          <span className="flex items-center gap-1">
                            ⭐ {court.rating}
                          </span>
                          <span>({court.reviewCount})</span>
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            {court.courtType}
                          </Badge>
                          <Badge variant="outline" className="bg-gray-100">
                            {court.district}
                          </Badge>
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        className="bg-green-600 hover:bg-green-700 shadow-md"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open('https://www.ksponco.or.kr/online/tennis/index.do', '_blank');
                        }}
                      >
                        예약하기
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-green-600" />
                        {court.address}
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-blue-600" />
                        {court.phone}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-orange-600" />
                        {court.openHours}
                      </div>
                      
                      {showDetailedInfo && (
                        <>
                          <div className="flex items-center gap-2">
                            <Users className="w-4 h-4 text-purple-600" />
                            코트 {court.courtCount}개
                          </div>
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            주간 {court.fee?.daytime} / 야간 {court.fee?.nighttime}
                          </div>
                          <div className="flex items-center gap-2">
                            <Car className="w-4 h-4 text-gray-600" />
                            {court.parkingInfo}
                          </div>
                        </>
                      )}
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex flex-wrap gap-2">
                        {court.facilities.map((facility) => (
                          <Badge key={facility} variant="outline" className="text-xs bg-gray-50">
                            {facility}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {showDetailedInfo && court.additionalInfo && (
                      <div className="mt-3 pt-3 border-t">
                        <p className="text-sm text-blue-700 bg-blue-50 p-3 rounded-lg">
                          💡 {court.additionalInfo}
                        </p>
                      </div>
                    )}

                    {selectedCourt?.id === court.id && (
                      <div className="mt-3 pt-3 border-t">
                        <p className="text-sm text-green-700 font-medium bg-green-50 p-2 rounded-lg">
                          📍 지도에서 정확한 위치를 확인하세요
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Quick Action Buttons */}
      <div className="mt-8 flex flex-wrap gap-4 justify-center">
        <Button
          variant="outline"
          className="bg-white hover:bg-gray-50"
          onClick={() => {
            setSearchTerm('');
            setSelectedDistrict('all');
            setSelectedCourtType('all');
            setSelectedCourt(null);
          }}
        >
          <Filter className="w-4 h-4 mr-2" />
          필터 초기화
        </Button>
        <Button
          variant="outline"
          className="bg-white hover:bg-gray-50"
          onClick={() => {
            if (filteredCourts.length > 0) {
              const randomCourt = filteredCourts[Math.floor(Math.random() * filteredCourts.length)];
              setSelectedCourt(randomCourt);
            }
          }}
        >
          🎲 랜덤 테니스장
        </Button>
        <Button
          variant="outline"
          className="bg-white hover:bg-gray-50"
          onClick={() => {
            const popularCourts = filteredCourts.filter(court => court.rating >= 4.5);
            if (popularCourts.length > 0) {
              setSelectedCourt(popularCourts[0]);
            }
          }}
        >
          ⭐ 인기 테니스장
        </Button>
        <Button
          variant="outline"
          className="bg-white hover:bg-gray-50"
          onClick={() => {
            window.open('https://yeyak.seoul.go.kr/web/main.do', '_blank');
          }}
        >
          🔗 서울시 공공예약 사이트
        </Button>
      </div>

      {/* 예약 정보 안내 */}
      <div className="mt-8 bg-gradient-to-r from-gray-50 to-blue-50 rounded-lg p-6 border border-gray-200">
        <h3 className="text-lg font-semibold mb-4 text-gray-900">📋 예약 이용 안내</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h4 className="font-medium mb-3 text-green-700">예약 방법</h4>
            <ul className="text-sm text-gray-600 space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-green-600">•</span>
                <span>서울시 공공예약 사이트 회원가입 필수</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">•</span>
                <span>실시간 예약 현황 확인 가능</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">•</span>
                <span>최대 7일 전 예약 가능</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600">•</span>
                <span>취소는 이용 시간 2시간 전까지</span>
              </li>
            </ul>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h4 className="font-medium mb-3 text-blue-700">이용 시간대</h4>
            <div className="text-sm text-gray-600 space-y-2">
              {reservationTimeSlots.map((slot) => (
                <div key={slot.time} className="flex justify-between items-center">
                  <span>{slot.label} ({slot.time})</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    slot.type === 'nighttime' 
                      ? 'bg-orange-100 text-orange-700' 
                      : 'bg-green-100 text-green-700'
                  }`}>
                    {slot.type === 'nighttime' ? '야간요금' : '주간요금'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 추가 CSS 스타일 */}
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #c1c1c1;
          border-radius: 3px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #a1a1a1;
        }
      `}</style>
    </div>
  );
};