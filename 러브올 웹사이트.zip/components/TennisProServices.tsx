import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Star, 
  MapPin, 
  Clock, 
  DollarSign, 
  Users, 
  Shield, 
  Search,
  Filter,
  MessageCircle,
  Calendar,
  Award,
  CheckCircle,
  PlayCircle,
  Heart,
  Zap
} from 'lucide-react';
import { tennisProServices, servicesByType, ServiceBooking, TennisProService } from '../data/tennisProServices';

interface TennisProServicesProps {
  user: any;
}

export const TennisProServices: React.FC<TennisProServicesProps> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedArea, setSelectedArea] = useState('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState('all');
  const [selectedServiceType, setSelectedServiceType] = useState('all');
  const [sortBy, setSortBy] = useState('rating');
  const [selectedService, setSelectedService] = useState<TennisProService | null>(null);
  const [showBookingDialog, setShowBookingDialog] = useState(false);

  // 필터링된 서비스 목록
  const filteredServices = tennisProServices.filter(service => {
    const matchesSearch = service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.providerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesArea = selectedArea === 'all' || service.location.area === selectedArea;
    
    const matchesPriceRange = selectedPriceRange === 'all' || 
      (selectedPriceRange === 'budget' && service.hourlyRate < 50000) ||
      (selectedPriceRange === 'mid' && service.hourlyRate >= 50000 && service.hourlyRate < 70000) ||
      (selectedPriceRange === 'premium' && service.hourlyRate >= 70000);
    
    const matchesServiceType = selectedServiceType === 'all' || service.serviceType === selectedServiceType;
    
    return matchesSearch && matchesArea && matchesPriceRange && matchesServiceType;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return b.rating - a.rating;
      case 'price-low':
        return a.hourlyRate - b.hourlyRate;
      case 'price-high':
        return b.hourlyRate - a.hourlyRate;
      case 'experience':
        return b.completedSessions - a.completedSessions;
      default:
        return 0;
    }
  });

  const getServiceTypeLabel = (type: string) => {
    const labels = {
      'lesson': '개인 레슨',
      'group-lesson': '그룹 레슨',
      'rally': '랠리 파트너',
      'sparring': '스파링'
    };
    return labels[type as keyof typeof labels] || type;
  };

  const getServiceTypeIcon = (type: string) => {
    const icons = {
      'lesson': '🎾',
      'group-lesson': '👥',
      'rally': '🔄',
      'sparring': '⚔️'
    };
    return icons[type as keyof typeof icons] || '🎾';
  };

  const handleBooking = (service: TennisProService) => {
    if (!user) {
      alert('로그인이 필요한 서비스입니다.');
      return;
    }
    setSelectedService(service);
    setShowBookingDialog(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">테니스 프로 서비스</h1>
        <p className="text-lg text-gray-600 mb-6">
          검증된 테니스 전문가들과 함께 실력을 향상시키고 즐거운 테니스를 경험해보세요.
        </p>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{tennisProServices.length}</div>
              <div className="text-sm text-gray-500">전문 코치</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {tennisProServices.reduce((sum, service) => sum + service.completedSessions, 0)}
              </div>
              <div className="text-sm text-gray-500">완료된 세션</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {(tennisProServices.reduce((sum, service) => sum + service.rating, 0) / tennisProServices.length).toFixed(1)}
              </div>
              <div className="text-sm text-gray-500">평균 평점</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">24/7</div>
              <div className="text-sm text-gray-500">예약 가능</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Filters and Search */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="서비스 이름, 코치명, 설명으로 검색..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <Select value={selectedServiceType} onValueChange={setSelectedServiceType}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="서비스 유형" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 서비스</SelectItem>
                  <SelectItem value="lesson">개인 레슨</SelectItem>
                  <SelectItem value="group-lesson">그룹 레슨</SelectItem>
                  <SelectItem value="rally">랠리 파트너</SelectItem>
                  <SelectItem value="sparring">스파링</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedArea} onValueChange={setSelectedArea}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="지역" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 지역</SelectItem>
                  <SelectItem value="강남구">강남구</SelectItem>
                  <SelectItem value="마포구">마포구</SelectItem>
                  <SelectItem value="서초구">서초구</SelectItem>
                  <SelectItem value="송파구">송파구</SelectItem>
                  <SelectItem value="성동구">성동구</SelectItem>
                  <SelectItem value="영등포구">영등포구</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="가격대" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">전체 가격</SelectItem>
                  <SelectItem value="budget">5만원 미만</SelectItem>
                  <SelectItem value="mid">5-7만원</SelectItem>
                  <SelectItem value="premium">7만원 이상</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="정렬" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">평점순</SelectItem>
                  <SelectItem value="price-low">가격 낮은순</SelectItem>
                  <SelectItem value="price-high">가격 높은순</SelectItem>
                  <SelectItem value="experience">경력순</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service Categories Tabs */}
      <Tabs value={selectedServiceType} onValueChange={setSelectedServiceType} className="mb-8">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">전체</TabsTrigger>
          <TabsTrigger value="lesson">개인 레슨</TabsTrigger>
          <TabsTrigger value="group-lesson">그룹 레슨</TabsTrigger>
          <TabsTrigger value="rally">랠리 파트너</TabsTrigger>
          <TabsTrigger value="sparring">스파링</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Results Info */}
      <div className="flex items-center justify-between mb-6">
        <p className="text-gray-600">
          총 <span className="font-semibold text-green-600">{filteredServices.length}</span>개의 서비스가 검색되었습니다.
        </p>
        {filteredServices.length > 0 && (
          <div className="text-sm text-gray-500">
            평균 요금: {Math.round(filteredServices.reduce((sum, service) => sum + service.hourlyRate, 0) / filteredServices.length).toLocaleString()}원/시간
          </div>
        )}
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-12 text-center">
                <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">검색 결과가 없습니다</h3>
                <p className="text-gray-600 mb-4">다른 검색 조건을 시도해보세요.</p>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedArea('all');
                    setSelectedPriceRange('all');
                    setSelectedServiceType('all');
                  }}
                >
                  필터 초기화
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          filteredServices.map((service) => (
            <Card key={service.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-0">
                {/* Service Image */}
                <div className="relative h-48 bg-gradient-to-r from-green-400 to-blue-500">
                  <ImageWithFallback
                    src={service.images[0]}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-white text-gray-900">
                      {getServiceTypeIcon(service.serviceType)} {getServiceTypeLabel(service.serviceType)}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    {service.isVerified && (
                      <Badge variant="secondary" className="bg-green-500 text-white">
                        <Shield className="w-3 h-3 mr-1" />
                        검증됨
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="p-6">
                  {/* Provider Info */}
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={service.providerImage} />
                      <AvatarFallback>{service.providerName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{service.providerName}</div>
                      <div className="text-sm text-gray-500">{service.experience}</div>
                    </div>
                  </div>

                  {/* Service Title */}
                  <h3 className="font-semibold text-lg mb-2 line-clamp-2">{service.title}</h3>
                  
                  {/* Rating and Stats */}
                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{service.rating}</span>
                      <span className="text-gray-500 text-sm">({service.reviewCount})</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      {service.completedSessions}회 완료
                    </div>
                  </div>

                  {/* Location and Price */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      {service.location.area}
                    </div>
                    <div className="flex items-center gap-1 font-semibold text-lg text-green-600">
                      <DollarSign className="w-4 h-4" />
                      {service.hourlyRate.toLocaleString()}원/시간
                    </div>
                  </div>

                  {/* Specialties */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {service.specialties.slice(0, 3).map((specialty) => (
                      <Badge key={specialty} variant="outline" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" className="flex-1">
                          상세보기
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>{service.title}</DialogTitle>
                          <DialogDescription>
                            {service.providerName}의 테니스 서비스 상세 정보
                          </DialogDescription>
                        </DialogHeader>
                        <ServiceDetailModal service={service} onBook={() => handleBooking(service)} />
                      </DialogContent>
                    </Dialog>
                    
                    <Button 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleBooking(service)}
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      예약하기
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Load More Button */}
      {filteredServices.length > 0 && (
        <div className="text-center mt-8">
          <Button variant="outline" size="lg">
            더 많은 서비스 보기
          </Button>
        </div>
      )}
    </div>
  );
};

// Service Detail Modal Component
const ServiceDetailModal: React.FC<{ service: TennisProService; onBook: () => void }> = ({ 
  service, 
  onBook 
}) => {
  return (
    <div className="space-y-6">
      {/* Provider Profile */}
      <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
        <Avatar className="w-16 h-16">
          <AvatarImage src={service.providerImage} />
          <AvatarFallback>{service.providerName[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold">{service.providerName}</h3>
            {service.isVerified && (
              <Badge className="bg-green-500">
                <Shield className="w-3 h-3 mr-1" />
                검증된 코치
              </Badge>
            )}
          </div>
          <p className="text-gray-600 mb-2">{service.experience}</p>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span>{service.rating} ({service.reviewCount}개 리뷰)</span>
            </div>
            <div>{service.completedSessions}회 완료</div>
            <div className="text-green-600">응답시간: {service.responseTime}</div>
          </div>
        </div>
      </div>

      {/* Service Description */}
      <div>
        <h4 className="font-semibold mb-2">서비스 소개</h4>
        <p className="text-gray-700 leading-relaxed">{service.description}</p>
      </div>

      {/* Certifications */}
      <div>
        <h4 className="font-semibold mb-2">자격증 및 인증</h4>
        <div className="flex flex-wrap gap-2">
          {service.certifications.map((cert) => (
            <Badge key={cert} variant="outline" className="bg-blue-50">
              <Award className="w-3 h-3 mr-1" />
              {cert}
            </Badge>
          ))}
        </div>
      </div>

      {/* Specialties */}
      <div>
        <h4 className="font-semibold mb-2">전문 분야</h4>
        <div className="flex flex-wrap gap-2">
          {service.specialties.map((specialty) => (
            <Badge key={specialty} variant="outline" className="bg-green-50">
              <Zap className="w-3 h-3 mr-1" />
              {specialty}
            </Badge>
          ))}
        </div>
      </div>

      {/* Location and Availability */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold mb-2">레슨 지역</h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span>{service.location.area} {service.location.specificLocation}</span>
            </div>
            <div className="text-sm text-gray-600">
              선호 테니스장: {service.location.preferredCourts.join(', ')}
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold mb-2">이용 가능 시간</h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-500" />
              <span>{service.availability.days.join(', ')}</span>
            </div>
            <div className="text-sm text-gray-600">
              {service.availability.timeSlots.join(', ')}
            </div>
          </div>
        </div>
      </div>

      {/* Pricing */}
      <div className="bg-green-50 p-4 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <h4 className="font-semibold">레슨 요금</h4>
          <div className="text-2xl font-bold text-green-600">
            {service.hourlyRate.toLocaleString()}원/시간
          </div>
        </div>
        <div className="text-sm text-gray-600">
          • 첫 레슨 50% 할인 (신규 회원)
          • 10회 이상 예약 시 10% 할인
          • 그룹 레슨 시 인당 요금 적용
        </div>
      </div>

      {/* Equipment and Languages */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold mb-2">제공 장비/서비스</h4>
          <div className="space-y-1">
            {service.equipment.map((item) => (
              <div key={item} className="flex items-center gap-2 text-sm">
                <CheckCircle className="w-4 h-4 text-green-500" />
                {item}
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="font-semibold mb-2">가능한 언어</h4>
          <div className="flex flex-wrap gap-2">
            {service.languages.map((lang) => (
              <Badge key={lang} variant="outline">{lang}</Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Images */}
      <div>
        <h4 className="font-semibold mb-2">레슨 사진</h4>
        <div className="grid grid-cols-2 gap-4">
          {service.images.map((image, index) => (
            <ImageWithFallback
              key={index}
              src={image}
              alt={`${service.providerName} 레슨 사진 ${index + 1}`}
              className="w-full h-32 object-cover rounded-lg"
            />
          ))}
        </div>
      </div>

      {/* Action Button */}
      <div className="flex gap-4 pt-4">
        <Button variant="outline" className="flex-1">
          <MessageCircle className="w-4 h-4 mr-2" />
          문의하기
        </Button>
        <Button 
          className="flex-1 bg-green-600 hover:bg-green-700"
          onClick={onBook}
        >
          <Calendar className="w-4 h-4 mr-2" />
          지금 예약하기
        </Button>
      </div>
    </div>
  );
};