import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Search, MapPin, Users, Calendar, Award } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroSectionProps {
  onPageChange: (page: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onPageChange }) => {
  return (
    <section className="relative bg-gradient-to-br from-green-50 to-blue-50 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            전국 공공 테니스장을 <span className="text-green-600">한 곳에서</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Love All에서 가까운 <br />
            테니스장을 찾고, 동호회 모임에 참여해보세요. 
            테니스를 사랑하는 사람들과 함께 즐거운 시간을 보내실 수 있습니다.
          </p>
          
          {/* Search Bar */}
          <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto mb-12">
            <div className="flex-1 relative">
              <Input
                placeholder="��역명이나 테니스장 이름을 검색하세요..."
                className="h-12 pl-12 text-lg"
              />
              <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
            </div>
            <Button 
              size="lg" 
              className="h-12 px-8 bg-green-600 hover:bg-green-700"
              onClick={() => onPageChange('courts')}
            >
              테니스장 찾기
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <div 
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onPageChange('courts')}
            >
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <MapPin className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">테니스장 찾기</h3>
              <p className="text-gray-600">전국 공공 테니스장 정보를 지도에서 확인하고 예약하세요</p>
            </div>
            
            <div 
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onPageChange('pro-services')}
            >
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">프로 서비스</h3>
              <p className="text-gray-600">검증된 프로 코치와 함께 레슨, 랠리, 스파링을 경험해보세요</p>
            </div>
            
            <div 
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onPageChange('meetings')}
            >
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">모임 참여</h3>
              <p className="text-gray-600">동호회 모임에 참여하거나 직접 모임을 개설해보세요</p>
            </div>
            
            <div 
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onPageChange('reviews')}
            >
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold mb-3">리뷰 & 후기</h3>
              <p className="text-gray-600">테니스장 이용 후기와 모임 후기를 확인하세요</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-green-200 rounded-full opacity-20"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-blue-200 rounded-full opacity-20"></div>
    </section>
  );
};