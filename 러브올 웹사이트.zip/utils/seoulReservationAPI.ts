// 서울시 공공예약 사이트 연동 유틸리티
export interface ReservationSlot {
  time: string;
  available: boolean;
  price: number;
  courtNumber: number;
}

export interface ReservationRequest {
  courtId: string;
  date: string;
  timeSlot: string;
  userInfo: {
    name: string;
    phone: string;
    email: string;
  };
}

// 서울시 공공예약 사이트 URL 생성
export function generateReservationUrl(courtId: string, date?: string): string {
  const baseUrl = 'https://yeyak.seoul.go.kr/web/main.do';
  
  // 특정 시설로 직접 이동하는 URL (실제 사이트 구조에 맞게 수정 필요)
  if (courtId) {
    return `${baseUrl}?facilityId=${courtId}&date=${date || ''}`;
  }
  
  return baseUrl;
}

// 예약 가능한 시간대 조회 (Mock 데이터)
export function getAvailableTimeSlots(courtId: string, date: string): ReservationSlot[] {
  // 실제 구현시에는 서울시 공공예약 API 호출
  const mockSlots: ReservationSlot[] = [
    { time: '06:00-08:00', available: true, price: 2000, courtNumber: 1 },
    { time: '08:00-10:00', available: false, price: 2000, courtNumber: 1 },
    { time: '10:00-12:00', available: true, price: 2000, courtNumber: 2 },
    { time: '12:00-14:00', available: true, price: 2000, courtNumber: 1 },
    { time: '14:00-16:00', available: false, price: 2000, courtNumber: 2 },
    { time: '16:00-18:00', available: true, price: 2000, courtNumber: 1 },
    { time: '18:00-20:00', available: true, price: 3000, courtNumber: 1 },
    { time: '20:00-22:00', available: false, price: 3000, courtNumber: 2 },
  ];
  
  return mockSlots;
}

// 예약 요청 처리 (실제로는 서울시 공공예약 사이트로 리다이렉트)
export function processReservation(request: ReservationRequest): void {
  // 실제 구현시에는 서울시 공공예약 사이트의 예약 프로세스를 따름
  const reservationUrl = generateReservationUrl(request.courtId, request.date);
  
  // 예약 정보를 로컬 스토리지에 임시 저장 (사용자 편의를 위해)
  localStorage.setItem('pendingReservation', JSON.stringify(request));
  
  // 서울시 공공예약 사이트로 이동
  window.open(reservationUrl, '_blank');
}

// 예약 상태 조회
export function getReservationStatus(reservationId: string): string {
  // Mock 구현 - 실제로는 API 호출
  const statuses = ['confirmed', 'pending', 'cancelled'];
  return statuses[Math.floor(Math.random() * statuses.length)];
}

// 예약 취소 처리
export function cancelReservation(reservationId: string): boolean {
  // Mock 구현 - 실제로는 서울시 공공예약 사이트 API 호출
  console.log(`예약 취소 요청: ${reservationId}`);
  return true;
}

// 사용자 예약 내역 조회
export function getUserReservations(userId: string): any[] {
  // Mock 구현 - 실제로는 서울시 공공예약 사이트 API 호출
  return [
    {
      id: 'res_001',
      courtName: '올림픽공원 테니스장',
      date: '2025-07-15',
      time: '10:00-12:00',
      status: 'confirmed',
      price: 4000
    },
    {
      id: 'res_002',
      courtName: '서울숲 테니스장',
      date: '2025-07-20',
      time: '18:00-20:00',
      status: 'pending',
      price: 5000
    }
  ];
}

// 실시간 예약 현황 업데이트
export function subscribeToReservationUpdates(courtId: string, callback: (slots: ReservationSlot[]) => void): void {
  // Mock 구현 - 실제로는 웹소켓 연결
  const interval = setInterval(() => {
    const updatedSlots = getAvailableTimeSlots(courtId, new Date().toISOString().split('T')[0]);
    callback(updatedSlots);
  }, 30000); // 30초마다 업데이트
  
  // 정리 함수 반환
  return () => clearInterval(interval);
}

// 예약 알림 설정
export function setReservationAlert(courtId: string, date: string, timeSlot: string): void {
  // Mock 구현 - 실제로는 푸시 알림 또는 이메일 알림 설정
  console.log(`예약 알림 설정: ${courtId}, ${date}, ${timeSlot}`);
  
  // 로컬 스토리지에 알림 정보 저장
  const alerts = JSON.parse(localStorage.getItem('reservationAlerts') || '[]');
  alerts.push({
    courtId,
    date,
    timeSlot,
    created: new Date().toISOString()
  });
  localStorage.setItem('reservationAlerts', JSON.stringify(alerts));
}

// 예약 정보 검증
export function validateReservationRequest(request: ReservationRequest): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (!request.courtId) errors.push('테니스장을 선택해주세요.');
  if (!request.date) errors.push('예약 날짜를 선택해주세요.');
  if (!request.timeSlot) errors.push('예약 시간을 선택해주세요.');
  if (!request.userInfo.name) errors.push('이름을 입력해주세요.');
  if (!request.userInfo.phone) errors.push('전화번호를 입력해주세요.');
  if (!request.userInfo.email) errors.push('이메일을 입력해주세요.');
  
  return {
    valid: errors.length === 0,
    errors
  };
}

// 예약 가능 여부 확인
export function checkReservationAvailability(courtId: string, date: string, timeSlot: string): boolean {
  const slots = getAvailableTimeSlots(courtId, date);
  const slot = slots.find(s => s.time === timeSlot);
  return slot ? slot.available : false;
}

// 예약 요금 계산
export function calculateReservationFee(courtId: string, timeSlot: string, duration: number = 2): number {
  const slots = getAvailableTimeSlots(courtId, new Date().toISOString().split('T')[0]);
  const slot = slots.find(s => s.time === timeSlot);
  
  if (!slot) return 0;
  
  return slot.price * duration;
}

// 서울시 공공예약 사이트 연동 상태 확인
export function checkReservationSystemStatus(): { online: boolean; message: string } {
  // Mock 구현 - 실제로는 서울시 공공예약 사이트 상태 확인
  const isOnline = Math.random() > 0.1; // 90% 확률로 온라인
  
  return {
    online: isOnline,
    message: isOnline ? '예약 시스템이 정상 작동 중입니다.' : '예약 시스템이 일시적으로 접근할 수 없습니다.'
  };
}