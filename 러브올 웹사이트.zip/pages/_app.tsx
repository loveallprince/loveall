import type { AppProps } from 'next/app'
import Head from 'next/head'
import '@/styles/globals.css'

export default function App({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <title>Love All - 전국 테니스장 통합 플랫폼</title>
        <meta name="description" content="전국 공공 테니스장 정보와 테니스 모임을 제공하는 프리미엄 플랫폼" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="keywords" content="테니스, 테니스장, 예약, 모임, 서울, 공공테니스장, 테니스코트" />
        <meta name="author" content="Love All Team" />
        <meta property="og:title" content="Love All - 전국 테니스장 통합 플랫폼" />
        <meta property="og:description" content="전국 공공 테니스장 정보와 테니스 모임을 제공하는 프리미엄 플랫폼" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://love-all-tennis.vercel.app" />
        <meta property="og:image" content="https://love-all-tennis.vercel.app/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Love All - 전국 테니스장 통합 플랫폼" />
        <meta name="twitter:description" content="전국 공공 테니스장 정보와 테니스 모임을 제공하는 프리미엄 플랫폼" />
        <meta name="twitter:image" content="https://love-all-tennis.vercel.app/og-image.png" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#16a34a" />
      </Head>
      <Component {...pageProps} />
    </>
  )
}