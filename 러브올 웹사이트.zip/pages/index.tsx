import { GetStaticProps } from 'next'
import App from '@/App'

export default function HomePage() {
  return <App />
}

export const getStaticProps: GetStaticProps = async () => {
  return {
    props: {},
    revalidate: 3600, // 1시간마다 재생성
  }
}