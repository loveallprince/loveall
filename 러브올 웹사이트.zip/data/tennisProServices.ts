// 테니스 프로 서비스 데이터 구조
export interface TennisProService {
  id: string;
  providerId: string;
  providerName: string;
  providerImage: string;
  title: string;
  description: string;
  serviceType: 'lesson' | 'rally' | 'sparring' | 'group-lesson';
  skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'professional';
  experience: string;
  certifications: string[];
  hourlyRate: number;
  location: {
    area: string;
    specificLocation?: string;
    preferredCourts: string[];
  };
  availability: {
    days: string[];
    timeSlots: string[];
  };
  rating: number;
  reviewCount: number;
  completedSessions: number;
  responseTime: string;
  languages: string[];
  equipment: string[];
  specialties: string[];
  images: string[];
  video?: string;
  isVerified: boolean;
  joinDate: string;
  lastActive: string;
}

export interface ServiceBooking {
  id: string;
  serviceId: string;
  providerId: string;
  clientId: string;
  date: string;
  timeSlot: string;
  duration: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  location: string;
  notes?: string;
  createdAt: string;
}

export interface ServiceReview {
  id: string;
  serviceId: string;
  providerId: string;
  clientId: string;
  clientName: string;
  rating: number;
  comment: string;
  date: string;
  helpful: number;
}

// Mock 데이터
export const tennisProServices: TennisProService[] = [
  {
    id: 'service_001',
    providerId: 'pro_001',
    providerName: '김테니스',
    providerImage: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=150',
    title: '전 국가대표 선수와 함께하는 맞춤형 테니스 레슨',
    description: '15년간의 프로 선수 경력과 10년의 지도 경험을 바탕으로 개인별 맞춤 레슨을 제공합니다. 기초부터 고급 기술까지 체계적으로 지도해드립니다.',
    serviceType: 'lesson',
    skillLevel: 'professional',
    experience: '프로 선수 15년, 지도 경력 10년',
    certifications: ['대한테니스협회 1급 지도자', 'PTR 프로페셔널', 'ITF 코치 자격증'],
    hourlyRate: 80000,
    location: {
      area: '강남구',
      specificLocation: '선릉역 인근',
      preferredCourts: ['올림픽공원 테니스장', '탄천종합운동장 테니스장']
    },
    availability: {
      days: ['월', '화', '수', '목', '금', '토'],
      timeSlots: ['09:00-12:00', '14:00-18:00', '19:00-21:00']
    },
    rating: 4.9,
    reviewCount: 127,
    completedSessions: 342,
    responseTime: '평균 2시간',
    languages: ['한국어', '영어'],
    equipment: ['라켓 대여', '볼 제공', '비디오 분석'],
    specialties: ['포핸드 교정', '서브 개선', '전술 지도', '멘탈 트레이닝'],
    images: [
      'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=400',
      'https://images.unsplash.com/photo-1544717440-6a9b137e8fbb?w=400'
    ],
    video: 'https://example.com/intro-video-001',
    isVerified: true,
    joinDate: '2023-03-15',
    lastActive: '2025-07-09'
  },
  {
    id: 'service_002',
    providerId: 'pro_002',
    providerName: '박코치',
    providerImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    title: '즐거운 랠리 파트너 서비스',
    description: '대학 테니스부 출신으로 안정적인 랠리를 통해 실전 감각을 기르실 수 있도록 도와드립니다. 편안하고 재미있는 분위기에서 실력 향상을 경험해보세요.',
    serviceType: 'rally',
    skillLevel: 'advanced',
    experience: '대학 테니스부 4년, 지도 경력 5년',
    certifications: ['대한테니스협회 2급 지도자', '생활체육지도자 자격증'],
    hourlyRate: 45000,
    location: {
      area: '마포구',
      specificLocation: '상암동 일대',
      preferredCourts: ['월드컵공원 테니스장', '한강시민공원 망원지구 테니스장']
    },
    availability: {
      days: ['화', '수', '목', '금', '토', '일'],
      timeSlots: ['10:00-12:00', '14:00-16:00', '18:00-20:00']
    },
    rating: 4.7,
    reviewCount: 89,
    completedSessions: 156,
    responseTime: '평균 1시간',
    languages: ['한국어'],
    equipment: ['볼 제공', '간단한 피드백'],
    specialties: ['스트로크 랠리', '볼레이 연습', '실전 감각 향상'],
    images: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
      'https://images.unsplash.com/photo-1526232761682-d26066babab3?w=400'
    ],
    isVerified: true,
    joinDate: '2023-08-20',
    lastActive: '2025-07-09'
  },
  {
    id: 'service_003',
    providerId: 'pro_003',
    providerName: '이선수',
    providerImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150',
    title: '여성 전용 테니스 그룹 레슨',
    description: '여성 선수 출신으로 편안하고 안전한 환경에서 테니스를 배우고 싶은 여성분들을 위한 그룹 레슨입니다. 최대 4명까지 소그룹으로 진행합니다.',
    serviceType: 'group-lesson',
    skillLevel: 'intermediate',
    experience: '실업팀 선수 8년, 여성 전용 레슨 3년',
    certifications: ['대한테니스협회 2급 지도자', '여성체육지도자 자격증'],
    hourlyRate: 35000,
    location: {
      area: '서초구',
      specificLocation: '양재역 인근',
      preferredCourts: ['양재시민의숲 테니스장', '탄천종합운동장 테니스장']
    },
    availability: {
      days: ['월', '수', '금', '토'],
      timeSlots: ['10:00-12:00', '14:00-16:00']
    },
    rating: 4.8,
    reviewCount: 64,
    completedSessions: 98,
    responseTime: '평균 3시간',
    languages: ['한국어'],
    equipment: ['라켓 대여 가능', '볼 제공'],
    specialties: ['기초 자세 교정', '친근한 분위기', '안전한 환경'],
    images: [
      'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400',
      'https://images.unsplash.com/photo-1544717440-6a9b137e8fbb?w=400'
    ],
    isVerified: true,
    joinDate: '2024-01-10',
    lastActive: '2025-07-08'
  },
  {
    id: 'service_004',
    providerId: 'pro_004',
    providerName: '최스파링',
    providerImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
    title: '고급자를 위한 실전 스파링',
    description: '실력 향상을 원하는 고급자들을 위한 치열한 스파링 서비스입니다. 실제 경기와 같은 환경에서 경기력 향상에 집중합니다.',
    serviceType: 'sparring',
    skillLevel: 'advanced',
    experience: '대학교 테니스 코치 7년, 주니어 선수 육성',
    certifications: ['대한테니스협회 1급 지도자', 'ITF 코치 레벨 2'],
    hourlyRate: 60000,
    location: {
      area: '송파구',
      specificLocation: '잠실 일대',
      preferredCourts: ['올림픽공원 테니스장', '잠실종합운동장 테니스장']
    },
    availability: {
      days: ['월', '화', '목', '금', '토'],
      timeSlots: ['07:00-09:00', '18:00-21:00']
    },
    rating: 4.6,
    reviewCount: 73,
    completedSessions: 134,
    responseTime: '평균 4시간',
    languages: ['한국어', '영어'],
    equipment: ['경기용 볼 제공', '스코어 기록'],
    specialties: ['실전 경기', '전술 분석', '멘탈 강화', '시합 준비'],
    images: [
      'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
      'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400'
    ],
    isVerified: true,
    joinDate: '2023-06-05',
    lastActive: '2025-07-09'
  },
  {
    id: 'service_005',
    providerId: 'pro_005',
    providerName: '정주니어',
    providerImage: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150',
    title: '주니어 선수 출신의 친근한 레슨',
    description: '젊고 에너지 넘치는 주니어 선수 출신으로 최신 테니스 기법과 트렌드를 바탕으로 즐겁게 가르쳐드립니다. 특히 젊은 층에게 인기가 많습니다.',
    serviceType: 'lesson',
    skillLevel: 'intermediate',
    experience: '주니어 랭킹 선수 출신, 지도 경력 3년',
    certifications: ['대한테니스협회 3급 지도자', '생활체육지도자'],
    hourlyRate: 40000,
    location: {
      area: '성동구',
      specificLocation: '건대입구역 인근',
      preferredCourts: ['서울숲 테니스장', '응봉공원 테니스장']
    },
    availability: {
      days: ['화', '수', '목', '금', '토', '일'],
      timeSlots: ['09:00-12:00', '15:00-18:00', '19:00-21:00']
    },
    rating: 4.5,
    reviewCount: 42,
    completedSessions: 67,
    responseTime: '평균 30분',
    languages: ['한국어'],
    equipment: ['볼 제공', 'SNS 피드백'],
    specialties: ['트렌디한 기법', '젊은 감각', '소셜미디어 활용'],
    images: [
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400',
      'https://images.unsplash.com/photo-1526232761682-d26066babab3?w=400'
    ],
    isVerified: false,
    joinDate: '2024-09-15',
    lastActive: '2025-07-09'
  },
  {
    id: 'service_006',
    providerId: 'pro_006',
    providerName: '홍베테랑',
    providerImage: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150',
    title: '30년 베테랑 코치의 체계적인 레슨',
    description: '30년간 테니스 코치로 활동하며 수많은 제자를 길러낸 베테랑 코치입니다. 체계적이고 정확한 기본기 교육으로 확실한 실력 향상을 보장합니다.',
    serviceType: 'lesson',
    skillLevel: 'professional',
    experience: '테니스 코치 30년, 프로 선수 육성 다수',
    certifications: ['대한테니스협회 1급 지도자', 'PTR 프로페셔널', '테니스 심판 자격증'],
    hourlyRate: 90000,
    location: {
      area: '영등포구',
      specificLocation: '여의도 일대',
      preferredCourts: ['여의도공원 테니스장', '한강시민공원 여의도지구']
    },
    availability: {
      days: ['월', '화', '수', '목', '금'],
      timeSlots: ['09:00-12:00', '14:00-17:00']
    },
    rating: 4.9,
    reviewCount: 203,
    completedSessions: 567,
    responseTime: '평균 6시간',
    languages: ['한국어', '영어', '일본어'],
    equipment: ['프로용 라켓 대여', '비디오 분석', '상세한 커리큘럼'],
    specialties: ['기본기 완성', '자세 교정', '체계적 교육', '프로 육성'],
    images: [
      'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400',
      'https://images.unsplash.com/photo-1544717440-6a9b137e8fbb?w=400'
    ],
    isVerified: true,
    joinDate: '2022-12-01',
    lastActive: '2025-07-08'
  }
];

// 서비스 타입별 분류
export const servicesByType = {
  lesson: tennisProServices.filter(service => service.serviceType === 'lesson'),
  rally: tennisProServices.filter(service => service.serviceType === 'rally'),
  sparring: tennisProServices.filter(service => service.serviceType === 'sparring'),
  'group-lesson': tennisProServices.filter(service => service.serviceType === 'group-lesson'),
};

// 지역별 서비스 분류
export const servicesByArea = tennisProServices.reduce((acc, service) => {
  const area = service.location.area;
  if (!acc[area]) {
    acc[area] = [];
  }
  acc[area].push(service);
  return acc;
}, {} as Record<string, TennisProService[]>);

// 가격대별 서비스 분류
export const servicesByPriceRange = {
  budget: tennisProServices.filter(service => service.hourlyRate < 50000),
  mid: tennisProServices.filter(service => service.hourlyRate >= 50000 && service.hourlyRate < 70000),
  premium: tennisProServices.filter(service => service.hourlyRate >= 70000),
};

// Mock 리뷰 데이터
export const serviceReviews: ServiceReview[] = [
  {
    id: 'review_001',
    serviceId: 'service_001',
    providerId: 'pro_001',
    clientId: 'user_001',
    clientName: '테니스러버',
    rating: 5,
    comment: '정말 전문적이고 체계적인 레슨이었습니다. 김테니스 코치님의 정확한 피드백 덕분에 단기간에 많은 발전을 이룰 수 있었어요. 특히 포핸드 자세 교정이 인상적이었습니다.',
    date: '2025-07-05',
    helpful: 12
  },
  {
    id: 'review_002',
    serviceId: 'service_002',
    providerId: 'pro_002',
    clientId: 'user_002',
    clientName: '주말테니스',
    rating: 5,
    comment: '박코치님과 함께한 랠리는 정말 즐거웠습니다. 제 수준에 맞춰서 볼을 쳐주시고, 자연스럽게 실력이 늘 수 있도록 도와주셨어요. 다음에도 꼭 예약할 예정입니다!',
    date: '2025-07-03',
    helpful: 8
  },
  {
    id: 'review_003',
    serviceId: 'service_003',
    providerId: 'pro_003',
    clientId: 'user_003',
    clientName: '테니스초보맘',
    rating: 5,
    comment: '여성 코치님이라서 더욱 편안하게 배울 수 있었어요. 그룹 레슨이지만 한 명 한 명 세심하게 봐주시고, 분위기도 화기애애해서 너무 좋았습니다.',
    date: '2025-06-30',
    helpful: 15
  }
];